(() => {
  const WEBSITE_ORIGIN = "http://localhost:3000";
  const SUPABASE_WEBSITE_STORAGE_KEY = "sb-uvexonxityogdjfuqmus-auth-token";
  const EXTENSION_SESSION_STORAGE_KEY = "brei:supabase-session";
  const SYNC_INTERVAL_MS = 3000;
  const BASE64_COOKIE_PREFIX = "base64-";

  if (
    window.location.origin !== WEBSITE_ORIGIN ||
    typeof chrome === "undefined" ||
    !chrome.runtime?.sendMessage
  ) {
    return;
  }

  let lastSessionValue;

  const parseCookies = () =>
    document.cookie
      .split(";")
      .map((cookie) => cookie.trim())
      .filter(Boolean)
      .reduce((cookies, cookie) => {
        const separatorIndex = cookie.indexOf("=");

        if (separatorIndex === -1) {
          return cookies;
        }

        const name = decodeURIComponent(cookie.slice(0, separatorIndex));
        const value = decodeURIComponent(cookie.slice(separatorIndex + 1));
        cookies[name] = value;
        return cookies;
      }, {});

  const decodeBase64Url = (value) => {
    const base64 = value.replace(/-/g, "+").replace(/_/g, "/");
    const padded = base64.padEnd(base64.length + ((4 - (base64.length % 4)) % 4), "=");
    return decodeURIComponent(
      Array.from(window.atob(padded), (character) =>
        `%${character.charCodeAt(0).toString(16).padStart(2, "0")}`,
      ).join(""),
    );
  };

  const normalizeSessionValue = (value) => {
    if (!value) {
      return null;
    }

    if (value.startsWith(BASE64_COOKIE_PREFIX)) {
      try {
        return decodeBase64Url(value.slice(BASE64_COOKIE_PREFIX.length));
      } catch (error) {
        console.error("Balkan Real Estate auth bridge could not decode Supabase cookie.", error);
        return null;
      }
    }

    return value;
  };

  const readChunkedCookie = (cookies, key) => {
    if (cookies[key]) {
      return cookies[key];
    }

    const chunks = [];

    for (let index = 0; index < 10; index += 1) {
      const chunk = cookies[`${key}.${index}`];

      if (!chunk) {
        break;
      }

      chunks.push(chunk);
    }

    return chunks.length > 0 ? chunks.join("") : null;
  };

  const readWebsiteSession = () => {
    const localStorageSession = window.localStorage.getItem(SUPABASE_WEBSITE_STORAGE_KEY);

    if (localStorageSession) {
      return localStorageSession;
    }

    return normalizeSessionValue(readChunkedCookie(parseCookies(), SUPABASE_WEBSITE_STORAGE_KEY));
  };

  const broadcastSession = async (sessionValue) => {
    const response = await chrome.runtime.sendMessage({
      type: "BREI_AUTH_SESSION_SYNC",
      sessionValue,
      storageKey: EXTENSION_SESSION_STORAGE_KEY,
      sourceOrigin: window.location.origin,
    });

    console.log("Balkan Real Estate auth bridge broadcast session:", response);
  };

  const syncSession = async () => {
    const sessionValue = readWebsiteSession();

    if (sessionValue === lastSessionValue) {
      return;
    }

    lastSessionValue = sessionValue;

    try {
      await broadcastSession(sessionValue);
    } catch (error) {
      console.error("Balkan Real Estate auth bridge failed to broadcast session.", error);
    }

    try {
      if (sessionValue) {
        await chrome.storage?.local?.set({ [EXTENSION_SESSION_STORAGE_KEY]: sessionValue });
        return;
      }

      await chrome.storage?.local?.remove(EXTENSION_SESSION_STORAGE_KEY);
    } catch (error) {
      console.error("Balkan Real Estate auth bridge failed to sync session.", error);
    }
  };

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "BREI_SYNC_AUTH_SESSION") {
      return false;
    }

    syncSession()
      .then(() => {
        sendResponse({ ok: true, hasSession: Boolean(lastSessionValue) });
      })
      .catch((error) => {
        console.error("Balkan Real Estate auth bridge manual sync failed.", error);
        sendResponse({ ok: false, hasSession: false });
      });

    return true;
  });

  window.addEventListener("storage", (event) => {
    if (event.key === SUPABASE_WEBSITE_STORAGE_KEY) {
      void syncSession();
    }
  });

  window.addEventListener("focus", () => {
    void syncSession();
  });

  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") {
      void syncSession();
    }
  });

  void syncSession();
  window.setInterval(() => {
    void syncSession();
  }, SYNC_INTERVAL_MS);
})();
