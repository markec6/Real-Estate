const DEFAULT_CREDITS_LIMIT = 5;
const CREDIT_COST_PER_UNLOCK = 1;
const PROFILE_CACHE_STORAGE_PREFIX = "brei:profile:";
const LISTING_DETECTOR_FILE = "content/listingDetector.js";
const INVALID_LISTING_MESSAGE =
  "Detekcija nije uspela: Na ovoj stranici nije pronađen pojedinačni oglas za nekretninu. Molimo otvorite konkretan oglas i pokušajte ponovo.";
const PARTIAL_DATA_MESSAGE =
  "Upozorenje: Ovaj oglas sadrži ograničen obim informacija na samoj stranici. AI analiza je izvršena na osnovu raspoloživih podataka.";

document.addEventListener("DOMContentLoaded", () => {
  const scanState = document.querySelector("#scan-state");
  const resultsState = document.querySelector("#results-state");
  const scanButton = document.querySelector("#scan-button");
  const scanNotice = document.querySelector("#scan-notice");
  const listingsSummaryTitle = document.querySelector("#listings-summary-title");
  const summaryBadge = document.querySelector("#summary-badge");
  const partialDataWarning = document.querySelector("#partial-data-warning");
  const accordion = document.querySelector("#listings-accordion");
  const profileCard = document.querySelector("#profile-card");
  const profileAvatar = document.querySelector("#profile-avatar");
  const profileLabel = document.querySelector("#profile-label");
  const profileSubtitle = document.querySelector("#profile-subtitle");
  const profileEmail = document.querySelector("#profile-email");
  const profileAction = document.querySelector("#profile-action");
  const creditsLabel = document.querySelector("#credits-label");
  const creditsPercent = document.querySelector("#credits-percent");
  const creditsProgress = document.querySelector("#credits-progress");
  const creditsFill = document.querySelector("#credits-fill");
  const dashboardLink = document.querySelector("#dashboard-link");
  const toast = document.querySelector("#toast");
  const devToggle = document.querySelector(".dev-state-toggle");

  if (
    !scanState ||
    !resultsState ||
    !scanButton ||
    !scanNotice ||
    !listingsSummaryTitle ||
    !summaryBadge ||
    !partialDataWarning ||
    !accordion ||
    !profileCard ||
    !profileAvatar ||
    !profileLabel ||
    !profileSubtitle ||
    !profileEmail ||
    !profileAction ||
    !creditsLabel ||
    !creditsPercent ||
    !creditsProgress ||
    !creditsFill ||
    !dashboardLink ||
    !toast
  ) {
    return;
  }

  function purgeListingDom() {
    accordion.replaceChildren();
    resultsState.querySelectorAll(".listing-card").forEach((card) => {
      card.remove();
    });
  }

  purgeListingDom();
  resultsState.classList.add("is-hidden");
  resultsState.setAttribute("aria-hidden", "true");

  const {
    EXTENSION_SESSION_STORAGE_KEY,
    SUPABASE_WEBSITE_STORAGE_KEY,
    WEBSITE_DASHBOARD_URL,
    WEBSITE_LOGIN_URL,
    WEBSITE_ORIGIN,
  } = window.breiConfig ?? {};

  const supabaseClient = window.breiSupabase;

  let currentUser = null;
  let currentProfile = null;
  let profileChannel = null;
  let profileChannelUserId = null;
  let lastStoredSessionValue;
  let lastAppliedAccessToken = null;
  let profileRequestId = 0;
  let authSyncTimer = null;
  let credits = 0;
  let creditsLimit = DEFAULT_CREDITS_LIMIT;
  let openListingId = null;
  let listings = [];
  let analyzingListingId = null;
  let scanTimer = null;
  let currentScanRequestId = 0;
  let currentDetectionResult = null;
  let toastTimer = null;

  const escapeHtml = (value) =>
    String(value ?? "").replace(/[&<>"']/g, (character) => {
      const entities = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;",
      };

      return entities[character];
    });

  const formatNumber = (value) =>
    new Intl.NumberFormat("sr-RS", {
      maximumFractionDigits: 0,
    }).format(value);

  const formatPercentage = (value) => {
    const absoluteValue = Math.abs(value);
    const precision = Number.isInteger(absoluteValue) ? 0 : 1;
    const sign = value > 0 ? "+" : "";

    return `${sign}${value.toFixed(precision)}%`;
  };

  const getMarketTone = (marketStatus) =>
    marketStatus === "Precenjeno" ? "warning" : "success";

  const clamp = (value, min, max) => Math.min(Math.max(value, min), max);

  const getProfileCacheKey = (userId) => `${PROFILE_CACHE_STORAGE_PREFIX}${userId}`;

  const getStoredSessionSnapshot = async () => {
    if (
      !EXTENSION_SESSION_STORAGE_KEY ||
      typeof chrome === "undefined" ||
      !chrome.storage?.local
    ) {
      return null;
    }

    const result = await chrome.storage.local.get(EXTENSION_SESSION_STORAGE_KEY);
    return result[EXTENSION_SESSION_STORAGE_KEY] ?? null;
  };

  const importSessionFromActiveWebsiteTab = async () => {
    if (
      !EXTENSION_SESSION_STORAGE_KEY ||
      !SUPABASE_WEBSITE_STORAGE_KEY ||
      !WEBSITE_ORIGIN ||
      typeof chrome === "undefined" ||
      !chrome.tabs?.query ||
      !chrome.scripting?.executeScript ||
      !chrome.storage?.local
    ) {
      return null;
    }

    try {
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const websiteTabs = await chrome.tabs.query({ url: `${WEBSITE_ORIGIN}/*` });
      const candidateTabs = [
        activeTab,
        ...websiteTabs.filter((tab) => tab.id !== activeTab?.id),
      ].filter(
        (tab) =>
          tab?.id &&
          (tab.url === WEBSITE_ORIGIN || tab.url?.startsWith(`${WEBSITE_ORIGIN}/`)),
      );

      for (const tab of candidateTabs) {
        const [injectionResult] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          args: [SUPABASE_WEBSITE_STORAGE_KEY],
          func: (storageKey) => {
          const base64CookiePrefix = "base64-";

          const decodeBase64Url = (value) => {
            const base64 = value.replace(/-/g, "+").replace(/_/g, "/");
            const padded = base64.padEnd(
              base64.length + ((4 - (base64.length % 4)) % 4),
              "=",
            );
            return decodeURIComponent(
              Array.from(atob(padded), (character) =>
                `%${character.charCodeAt(0).toString(16).padStart(2, "0")}`,
              ).join(""),
            );
          };

          const normalizeSessionValue = (value) => {
            if (!value) {
              return null;
            }

            if (value.startsWith(base64CookiePrefix)) {
              return decodeBase64Url(value.slice(base64CookiePrefix.length));
            }

            return value;
          };

          const readChunkedCookie = (cookies, key) => {
            if (cookies[key]) {
              return cookies[key];
            }

            const chunks = [];

            for (let index = 0; index < 10; index += 1) {
              const chunk = cookies[`${key}.${index}`];

              if (!chunk) {
                break;
              }

              chunks.push(chunk);
            }

            return chunks.length > 0 ? chunks.join("") : null;
          };

          const readCookies = () =>
            document.cookie
              .split(";")
              .map((cookie) => cookie.trim())
              .filter(Boolean)
              .reduce((cookies, cookie) => {
                const separatorIndex = cookie.indexOf("=");

                if (separatorIndex === -1) {
                  return cookies;
                }

                cookies[decodeURIComponent(cookie.slice(0, separatorIndex))] =
                  decodeURIComponent(cookie.slice(separatorIndex + 1));
                return cookies;
              }, {});

          const localStorageSession = window.localStorage.getItem(storageKey);

          if (localStorageSession) {
            return localStorageSession;
          }

          const cookies = readCookies();
          return normalizeSessionValue(readChunkedCookie(cookies, storageKey));
          },
        });

        const sessionValue =
          typeof injectionResult?.result === "string" ? injectionResult.result : null;

        if (sessionValue) {
          await chrome.storage.local.set({ [EXTENSION_SESSION_STORAGE_KEY]: sessionValue });
          return sessionValue;
        }
      }

      if (candidateTabs.length > 0) {
        await chrome.storage.local.remove(EXTENSION_SESSION_STORAGE_KEY);
      }

      return null;
    } catch (error) {
      console.error("[Extension Auth] Could not import session from website tab.", error);
      return null;
    }
  };

  const getCachedProfile = async (userId) => {
    if (!userId || typeof chrome === "undefined" || !chrome.storage?.local) {
      return null;
    }

    try {
      const cacheKey = getProfileCacheKey(userId);
      const result = await chrome.storage.local.get(cacheKey);
      return result[cacheKey] ?? null;
    } catch (error) {
      console.error("[Extension Auth] Could not read cached profile.", error);
      return null;
    }
  };

  const setCachedProfile = async (userId, profile) => {
    if (!userId || !profile || typeof chrome === "undefined" || !chrome.storage?.local) {
      return;
    }

    try {
      await chrome.storage.local.set({ [getProfileCacheKey(userId)]: profile });
    } catch (error) {
      console.error("[Extension Auth] Could not cache profile.", error);
    }
  };

  const parseStoredSession = (storedSession) => {
    if (!storedSession) {
      return null;
    }

    try {
      const parsedSession =
        typeof storedSession === "string" ? JSON.parse(storedSession) : storedSession;
      const session = parsedSession.currentSession || parsedSession.session || parsedSession;

      if (session?.access_token && session?.refresh_token && session?.user) {
        return {
          session,
          user: session.user,
          accessToken: session.access_token,
          refreshToken: session.refresh_token,
        };
      }
    } catch (error) {
      console.error("[Extension Auth] Stored session could not be parsed:", error);
    }

    return null;
  };

  const restoreSessionIfChanged = async (auth) => {
    if (!auth?.accessToken || !auth?.refreshToken || !supabaseClient?.auth?.setSession) {
      return;
    }

    if (auth.accessToken === lastAppliedAccessToken) {
      return;
    }

    const { error } = await supabaseClient.auth.setSession({
      access_token: auth.accessToken,
      refresh_token: auth.refreshToken,
    });

    if (error) {
      throw error;
    }

    lastAppliedAccessToken = auth.accessToken;
  };

  const getNumberValue = (...values) => {
    const value = values.find((candidate) => Number.isFinite(Number(candidate)));
    return value === undefined ? 0 : Number(value);
  };

  const getDisplayName = (profile, user) => {
    const fullName = (profile?.fullname || profile?.full_name || profile?.name)?.trim();
    return fullName || user?.email || "Korisnik";
  };

  const getInitials = (value) => {
    const normalized = String(value ?? "")
      .replace(/@.*/, "")
      .trim();

    if (!normalized) {
      return "BR";
    }

    const parts = normalized.split(/\s+/).filter(Boolean);

    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
    }

    return normalized.slice(0, 2).toUpperCase();
  };

  const getTierLabel = (profile) => {
    const status = profile?.subscription_status ?? "trial";
    const labels = {
      active: "Active subscriber",
      canceled: "Subscription canceled",
      expired: "Subscription expired",
      trial: "Beta Access User",
    };

    return labels[status] ?? status.replace(/_/g, " ");
  };

  const setProfileStateClass = (state) => {
    profileCard.classList.toggle("is-loading", state === "loading");
    profileCard.classList.toggle("is-unauthenticated", state === "unauthenticated");
    profileCard.classList.toggle("is-error", state === "error");
  };

  const showToast = (message) => {
    window.clearTimeout(toastTimer);
    toast.textContent = message;
    toast.classList.add("is-visible");
    toast.setAttribute("aria-hidden", "false");

    toastTimer = window.setTimeout(() => {
      toast.classList.remove("is-visible");
      toast.setAttribute("aria-hidden", "true");
    }, 3200);
  };

  const updateCredits = () => {
    const safeLimit = Math.max(creditsLimit, 1);
    const percentage = clamp(Math.round((credits / safeLimit) * 100), 0, 100);

    creditsLabel.textContent = `Credits: ${credits} / ${creditsLimit}`;
    creditsPercent.textContent = `${percentage}%`;
    creditsProgress.setAttribute("aria-label", `Krediti: ${credits} od ${creditsLimit}`);
    creditsFill.style.width = `${percentage}%`;
  };

  const renderUnauthenticatedProfile = () => {
    currentUser = null;
    currentProfile = null;
    credits = 0;
    creditsLimit = DEFAULT_CREDITS_LIMIT;
    setProfileStateClass("unauthenticated");
    profileAvatar.textContent = "BR";
    profileLabel.textContent = "Niste prijavljeni";
    profileSubtitle.textContent = "Kliknite Prijava da povežete nalog.";
    profileEmail.textContent = "";
    profileAction.textContent = "Prijava";
    profileAction.href = WEBSITE_LOGIN_URL || "#";
    dashboardLink.href = WEBSITE_DASHBOARD_URL || "#";
    updateCredits();
  };

  const renderAuthenticatedProfile = (profile, user) => {
    const displayName = getDisplayName(profile, user);
    credits = clamp(
      Math.floor(getNumberValue(profile?.credits_remaining, profile?.credits)),
      0,
      Number.MAX_SAFE_INTEGER,
    );
    creditsLimit = Math.max(
      Math.floor(getNumberValue(profile?.credits_limit, profile?.credits_total, DEFAULT_CREDITS_LIMIT)),
      1,
    );

    setProfileStateClass("authenticated");
    profileAvatar.textContent = getInitials(displayName);
    profileLabel.textContent = displayName;
    profileSubtitle.textContent = getTierLabel(profile);
    profileEmail.textContent = user?.email || profile?.email || "";
    profileAction.textContent = "Upgrade";
    profileAction.href = WEBSITE_DASHBOARD_URL || "#";
    dashboardLink.href = WEBSITE_DASHBOARD_URL || "#";
    updateCredits();
  };

  const unsubscribeFromProfileChanges = () => {
    if (!profileChannel) {
      profileChannelUserId = null;
      return;
    }

    supabaseClient.removeChannel(profileChannel);
    profileChannel = null;
    profileChannelUserId = null;
  };

  const subscribeToProfileChanges = (userId) => {
    if (!userId || profileChannelUserId === userId) {
      return;
    }

    unsubscribeFromProfileChanges();
    profileChannelUserId = userId;

    profileChannel = supabaseClient
      .channel(`profile-credit-${userId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          filter: `id=eq.${userId}`,
          schema: "public",
          table: "profiles",
        },
        (payload) => {
          if (currentUser?.id !== userId || payload.new?.id !== userId) {
            console.warn("[Extension Auth] Ignored profile update for inactive user.", {
              activeUserId: currentUser?.id ?? null,
              subscribedUserId: userId,
              profileUserId: payload.new?.id ?? null,
            });
            return;
          }

          currentProfile = payload.new;
          void setCachedProfile(userId, currentProfile);
          renderAuthenticatedProfile(currentProfile, currentUser);
        },
      )
      .subscribe((status, error) => {
        if (error) {
          console.error("Supabase profile realtime subscription error.", error);
        }

        if (status === "CHANNEL_ERROR") {
          console.error("Supabase profile realtime channel failed.");
        }
      });
  };

  const fetchAndRenderProfile = async (user, requestId = ++profileRequestId) => {
    if (!user?.id || !supabaseClient?.from) {
      return null;
    }

    try {
      const { data, error } = await supabaseClient
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .maybeSingle();

      if (error) {
        throw error;
      }

      if (requestId !== profileRequestId || currentUser?.id !== user.id) {
        return null;
      }

      if (!data) {
        console.warn("[Extension Auth] No profile row found for active user.", user.id);
        return null;
      }

      currentProfile = data;
      await setCachedProfile(user.id, data);
      renderAuthenticatedProfile(currentProfile, currentUser);
      subscribeToProfileChanges(user.id);
      return data;
    } catch (error) {
      console.error("[Extension Profile Fetch Error:]", error);
      if (currentUser?.id === user.id) {
        renderAuthenticatedProfile(currentProfile, currentUser);
      }
      return null;
    }
  };

  const applyStoredSession = async (storedSession, { clearOnMissing = false } = {}) => {
    const auth = parseStoredSession(storedSession);

    if (!auth?.user?.id) {
      lastStoredSessionValue = storedSession ?? null;
      lastAppliedAccessToken = null;
      profileRequestId += 1;
      unsubscribeFromProfileChanges();

      if (clearOnMissing || !currentUser) {
        renderUnauthenticatedProfile();
      }

      return null;
    }

    lastStoredSessionValue = storedSession;
    const cachedProfile = await getCachedProfile(auth.user.id);
    const immediateProfile =
      cachedProfile ?? (currentUser?.id === auth.user.id ? currentProfile : null);

    currentUser = auth.user;
    currentProfile = immediateProfile;
    renderAuthenticatedProfile(currentProfile, currentUser);

    try {
      await restoreSessionIfChanged(auth);
    } catch (error) {
      console.error("[Extension Auth] Stored session restore failed:", error);
      return currentProfile;
    }

    return fetchAndRenderProfile(currentUser);
  };

  const initializeAuthState = async () => {
    try {
      await importSessionFromActiveWebsiteTab();
      const storedSession = await getStoredSessionSnapshot();

      if (storedSession) {
        await applyStoredSession(storedSession, { clearOnMissing: true });
        return;
      }

      const { data, error } = supabaseClient?.auth?.getSession
        ? await supabaseClient.auth.getSession()
        : { data: null, error: null };

      if (error) {
        throw error;
      }

      if (data?.session) {
        await applyStoredSession(
          JSON.stringify({
            currentSession: data.session,
            expiresAt: data.session.expires_at ?? null,
          }),
          { clearOnMissing: true },
        );
        return;
      }

      renderUnauthenticatedProfile();
    } catch (error) {
      console.error("[Extension Auth] Initial auth state failed:", error);
      if (currentUser) {
        renderAuthenticatedProfile(currentProfile, currentUser);
      } else {
        renderUnauthenticatedProfile();
      }
    }
  };

  const setScannerLoading = (isLoading) => {
    scanButton.classList.toggle("is-loading", isLoading);
    scanButton.toggleAttribute("disabled", isLoading);
    scanButton.setAttribute("aria-busy", String(isLoading));
  };

  const clearScanTimer = () => {
    if (scanTimer) {
      window.clearTimeout(scanTimer);
      scanTimer = null;
    }
  };

  const setScanNotice = (message = "") => {
    scanNotice.textContent = message;
    scanNotice.classList.toggle("is-hidden", !message);
    scanNotice.setAttribute("aria-hidden", String(!message));
  };

  const setPartialDataWarning = (isVisible) => {
    partialDataWarning.textContent = isVisible ? PARTIAL_DATA_MESSAGE : "";
    partialDataWarning.classList.toggle("is-hidden", !isVisible);
    partialDataWarning.setAttribute("aria-hidden", String(!isVisible));
  };

  const resetScanResults = () => {
    currentDetectionResult = null;
    listings = [];
    openListingId = null;
    analyzingListingId = null;
    setPartialDataWarning(false);
    purgeListingDom();
    renderListings();
  };

  const setResultsVisible = (isVisible) => {
    scanState.classList.toggle("is-hidden", isVisible);
    resultsState.classList.toggle("is-hidden", !isVisible);
    scanState.setAttribute("aria-hidden", String(isVisible));
    resultsState.setAttribute("aria-hidden", String(!isVisible));
    devToggle?.classList.toggle("is-active", isVisible);
    devToggle?.setAttribute("aria-pressed", String(isVisible));
  };

  const updateListingsSummary = () => {
    const count = listings.length;
    listingsSummaryTitle.textContent =
      count === 1
        ? "Pronađen pojedinačni oglas na stranici"
        : `Pronađeno ${count} oglasa na stranici`;
    summaryBadge.textContent = count === 1 ? "1 aktivan" : `${count} aktivnih`;
  };

  const isValidDetectionPayload = (result) => {
    const signals = result?.detection?.signals;
    const passesStrongJsonLdRule = signals?.has_strong_json_ld === true;
    const passesDomHeuristicRule =
      signals?.has_price === true &&
      signals?.has_explicit_dom_area === true &&
      signals?.has_property_context === true;
    const passesListingRules =
      signals?.is_collection_like === false &&
      signals?.is_generic_blocked_page === false &&
      (passesStrongJsonLdRule || passesDomHeuristicRule);

    return (
      result?.schema_version === 1 &&
      typeof result.is_valid_listing === "boolean" &&
      typeof result.has_partial_data === "boolean" &&
      Number.isInteger(result.completeness_score) &&
      Array.isArray(result.missing_fields) &&
      result.detection &&
      typeof result.detection.method === "string" &&
      signals &&
      (result.listing === null || typeof result.listing === "object") &&
      (!result.is_valid_listing || passesListingRules)
    );
  };

  const formatDetectedPrice = (price) => {
    if (price?.raw) {
      return price.raw;
    }

    if (!Number.isFinite(price?.value)) {
      return "Cena nije pronađena";
    }

    const currencyLabels = {
      EUR: "€",
      USD: "$",
      GBP: "£",
      RSD: "RSD",
    };

    return `${formatNumber(price.value)} ${currencyLabels[price.currency] ?? price.currency ?? ""}`.trim();
  };

  const createDetectedListingId = (listing) => {
    const source = listing?.listing_url || `${listing?.portal_name ?? "detected"}-${Date.now()}`;
    let hash = 0;

    for (let index = 0; index < source.length; index += 1) {
      hash = (hash * 31 + source.charCodeAt(index)) >>> 0;
    }

    return `detected-${hash.toString(36)}`;
  };

  const mapDetectionToListing = (detectionResult) => {
    const detectedListing = detectionResult.listing;

    return {
      id: createDetectedListingId(detectedListing),
      title: detectedListing.title || "Naslov oglasa nije pronađen",
      location: detectedListing.location || "Lokacija nije pronađena",
      price: formatDetectedPrice(detectedListing.price),
      unlocked: false,
      detection: detectionResult,
      hasPartialData: detectionResult.has_partial_data,
      isDetectionValid: detectionResult.is_valid_listing,
    };
  };

  const getActiveTab = async () => {
    if (typeof chrome === "undefined" || !chrome.tabs?.query) {
      return null;
    }

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab ?? null;
  };

  const canInspectTab = (tab) => Boolean(tab?.id && /^https?:\/\//i.test(tab.url ?? ""));

  const inspectActiveTabListing = async () => {
    if (typeof chrome === "undefined" || !chrome.scripting?.executeScript) {
      return null;
    }

    const tab = await getActiveTab();

    if (!canInspectTab(tab)) {
      return null;
    }

    const [injectionResult] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: [LISTING_DETECTOR_FILE],
    });

    return injectionResult?.result ?? null;
  };

  const showInvalidScanState = () => {
    resetScanResults();
    setResultsVisible(false);
    setScanNotice(INVALID_LISTING_MESSAGE);
  };

  const getListingById = (id) => listings.find((listing) => listing.id === id);

  const renderInsightItems = (analysis) => {
    const riskItems = analysis.insights.risks.map((risk) => ({
      icon: "⚠️",
      text: risk,
      tone: "warning",
    }));
    const highlightItems = analysis.insights.highlights.map((highlight) => ({
      icon: "✅",
      text: highlight,
      tone: "success",
    }));
    const insightItems = [...riskItems, ...highlightItems];

    if (insightItems.length === 0) {
      return `
        <li class="risk-item risk-success">
          <span class="risk-icon" aria-hidden="true">✅</span>
          <span>Nema izdvojenih rizika ili prednosti u dostupnim podacima oglasa.</span>
        </li>
      `;
    }

    return insightItems
      .map(
        (item) => `
          <li class="risk-item risk-${item.tone}">
            <span class="risk-icon" aria-hidden="true">${item.icon}</span>
            <span>${escapeHtml(item.text)}</span>
          </li>
        `,
      )
      .join("");
  };

  const renderQuickPrompts = (listing) =>
    listing.analysis.dynamic_quick_prompts
      .map(
        (prompt) => `
          <button
            class="prompt-chip"
            type="button"
            data-listing-id="${listing.id}"
            data-prompt-label="${escapeHtml(prompt.label)}"
            data-prompt-query="${escapeHtml(prompt.prompt_query)}"
            aria-pressed="false"
          >
            ${escapeHtml(prompt.label)}
          </button>
        `,
      )
      .join("");

  const renderAnalysisSkeleton = (listing) => `
    <div
      class="accordion-panel skeleton-panel"
      id="panel-${listing.id}"
      role="region"
      aria-labelledby="trigger-${listing.id}"
      aria-busy="true"
    >
      <div class="analysis-grid skeleton-grid">
        <section class="analysis-module skeleton-status-card" aria-live="polite">
          <p class="skeleton-status-text">
            <span class="skeleton-pulse-dot" aria-hidden="true"></span>
            AI analizira tržišne podatke...
          </p>
        </section>

        <section class="analysis-module skeleton-card skeleton-financials" aria-label="Učitavanje finansijskog pregleda">
          <div class="skeleton-box skeleton-price-box"></div>
          <div class="skeleton-badge-row">
            <span class="skeleton-box skeleton-badge"></span>
            <span class="skeleton-box skeleton-badge"></span>
          </div>
        </section>

        <section class="analysis-module skeleton-card skeleton-score" aria-label="Učitavanje AI ocene ponude">
          <div class="skeleton-box skeleton-score-bar"></div>
        </section>

        <section class="analysis-module skeleton-card skeleton-insights" aria-label="Učitavanje rizika i prednosti">
          <div class="skeleton-box skeleton-line skeleton-line-100"></div>
          <div class="skeleton-box skeleton-line skeleton-line-80"></div>
          <div class="skeleton-box skeleton-line skeleton-line-60"></div>
        </section>

        <section class="analysis-module skeleton-card skeleton-prompts" aria-label="Učitavanje brzih upita">
          <div class="skeleton-chip-row">
            <span class="skeleton-box skeleton-chip"></span>
            <span class="skeleton-box skeleton-chip"></span>
            <span class="skeleton-box skeleton-chip"></span>
          </div>
        </section>
      </div>
    </div>
  `;

  const renderListingDetails = (listing) => {
    const { analysis } = listing;

    if (!analysis) {
      return "";
    }

    const score = analysis.deal_score.score;
    const scoreWidth = Math.min(Math.max(score * 10, 0), 100);
    const marketTone = getMarketTone(analysis.financials.market_status);
    const marketComparison = `${analysis.financials.market_status} (${formatPercentage(
      analysis.financials.price_difference_percentage,
    )})`;

    return `
      <div class="accordion-panel analysis-ready" id="panel-${listing.id}" role="region" aria-labelledby="trigger-${listing.id}">
        <div class="analysis-grid">
          <section class="analysis-module market-module" aria-label="Finansijski i tržišni pregled">
            <p class="module-kicker">FINANSIJSKI I TRŽIŠNI PREGLED</p>
            <div class="price-block compact">
              <p class="price-value">${formatNumber(analysis.financials.price_per_sqm)} € / m²</p>
              <p class="muted-label">Oglašena cena po m²</p>
            </div>
            <div class="module-tags">
              <span class="badge badge-${marketTone}">${escapeHtml(marketComparison)}</span>
              <span class="badge badge-owner">${escapeHtml(analysis.financials.seller_type)}</span>
            </div>
          </section>

          <section class="analysis-module score-module" aria-label="AI ocena ponude">
            <div class="module-title-row">
              <p class="module-kicker">AI OCENA PONUDE</p>
              <strong>${score.toFixed(1)} / 10</strong>
            </div>
            <div class="progress-track score-track" aria-label="AI ocena: ${score.toFixed(1)} od 10">
              <div class="progress-fill score-fill" style="width: ${scoreWidth}%"></div>
            </div>
            <p class="score-caption">${escapeHtml(analysis.deal_score.verdict)}</p>
          </section>

          <section class="analysis-module risk-module" aria-label="AI detektor rizika i prednosti">
            <p class="module-kicker">AI DETEKTOR RIZIKA I PREDNOSTI</p>
            <ul class="risk-list">
              ${renderInsightItems(analysis)}
            </ul>
          </section>

          <section class="analysis-module action-module" aria-label="Brze akcije">
            <p class="module-kicker">BRZE AKCIJE</p>
            <div class="prompt-chips" role="group" aria-label="Brzi upiti">
              ${renderQuickPrompts(listing)}
            </div>
            <div
              class="prompt-answer"
              id="prompt-answer-${listing.id}"
              aria-live="polite"
              aria-hidden="true"
            ></div>
            <button class="save-dashboard-button" type="button" data-listing-id="${listing.id}">Sačuvaj na Dashboard</button>
            <p class="action-feedback" id="feedback-${listing.id}" aria-live="polite"></p>
          </section>
        </div>
      </div>
    `;
  };

  const renderListing = (listing) => {
    const isOpen = listing.unlocked && listing.id === openListingId;
    const cardStateClass = listing.unlocked ? "is-unlocked" : "is-locked";
    const isAnalyzing = analyzingListingId === listing.id;
    const lockedHelpText = listing.analysisError || "Analiza ovog oglasa još nije pokrenuta.";

    if (isAnalyzing) {
      return `
        <article class="listing-card is-unlocked is-open is-analysis-loading" data-listing-id="${listing.id}">
          <button
            id="trigger-${listing.id}"
            class="listing-trigger skeleton-trigger"
            type="button"
            data-listing-id="${listing.id}"
            aria-expanded="true"
            aria-controls="panel-${listing.id}"
            aria-busy="true"
            disabled
          >
            <span class="listing-main">
              <span class="listing-title">${escapeHtml(listing.title)}</span>
              <span class="listing-meta">${escapeHtml(listing.location)}</span>
            </span>
            <span class="listing-side">
              <strong>${escapeHtml(listing.price)}</strong>
              <span class="badge badge-warning">Analiza u toku</span>
            </span>
          </button>

          ${renderAnalysisSkeleton(listing)}
        </article>
      `;
    }

    if (!listing.unlocked) {
      return `
        <article class="listing-card ${cardStateClass}" data-listing-id="${listing.id}">
          <div class="listing-trigger locked-trigger" aria-describedby="locked-help-${listing.id}">
            <span class="listing-main">
              <span class="listing-title">${escapeHtml(listing.title)}</span>
              <span class="listing-meta">${escapeHtml(listing.location)}</span>
            </span>
            <span class="listing-side">
              <strong>${escapeHtml(listing.price)}</strong>
              <button
                class="unlock-button unlock-inline ${isAnalyzing ? "is-loading" : ""}"
                type="button"
                data-listing-id="${listing.id}"
                ${isAnalyzing ? "disabled" : ""}
                aria-busy="${String(isAnalyzing)}"
              >
                <span aria-hidden="true">${isAnalyzing ? "⏳" : "🔒"}</span>
                <span>${isAnalyzing ? "Analiziram..." : "Otključaj analizu (-1 kredit)"}</span>
              </button>
            </span>
          </div>
          <p id="locked-help-${listing.id}" class="locked-help ${
            listing.analysisError ? "unlock-error" : ""
          }">${escapeHtml(lockedHelpText)}</p>
        </article>
      `;
    }

    return `
      <article class="listing-card ${cardStateClass} ${isOpen ? "is-open" : ""}" data-listing-id="${listing.id}">
        <button
          id="trigger-${listing.id}"
          class="listing-trigger"
          type="button"
          data-listing-id="${listing.id}"
          aria-expanded="${String(isOpen)}"
          aria-controls="panel-${listing.id}"
        >
          <span class="listing-main">
            <span class="listing-title">${escapeHtml(listing.title)}</span>
            <span class="listing-meta">${escapeHtml(listing.location)}</span>
          </span>
          <span class="listing-side">
            <strong>${escapeHtml(listing.price)}</strong>
            <span class="badge badge-success">Analizirano</span>
          </span>
          <span class="accordion-indicator" aria-hidden="true">
            <svg class="accordion-icon accordion-icon-arrow" viewBox="0 0 24 24" focusable="false">
              <path d="m6 9 6 6 6-6"></path>
            </svg>
            <svg class="accordion-icon accordion-icon-close" viewBox="0 0 24 24" focusable="false">
              <path d="M6 6l12 12M18 6 6 18"></path>
            </svg>
          </span>
        </button>

        ${isOpen ? renderListingDetails(listing) : ""}
      </article>
    `;
  };

  const renderListings = () => {
    updateListingsSummary();

    if (listings.length === 0) {
      purgeListingDom();
      return;
    }

    accordion.innerHTML = listings.map(renderListing).join("");
  };

  const consumeCredit = async () => {
    if (!currentUser || !currentProfile) {
      showToast("Prijavite se na sajtu da biste koristili analizu.");
      return null;
    }

    const previousCredits = credits;
    const nextCredits = previousCredits - CREDIT_COST_PER_UNLOCK;

    if (previousCredits <= 0 || nextCredits < 0) {
      showToast("Nemate dovoljno kredita.");
      return null;
    }

    const { data, error } = await supabaseClient
      .from("profiles")
      .update({ credits_remaining: nextCredits })
      .eq("id", currentUser.id)
      .eq("credits_remaining", previousCredits)
      .select("*")
      .maybeSingle();

    if (error) {
      throw error;
    }

    if (!data) {
      await fetchAndRenderProfile(currentUser);
      showToast("Krediti su promenjeni. Pokušajte ponovo.");
      return null;
    }

    currentProfile = data;
    renderAuthenticatedProfile(currentProfile, currentUser);
    return data;
  };

  const unlockListing = async (id) => {
    const listing = getListingById(id);

    if (!listing || listing.unlocked || analyzingListingId) {
      return;
    }

    if (!currentDetectionResult?.is_valid_listing || !listing.isDetectionValid) {
      showInvalidScanState();
      return;
    }

    if (!currentUser || !currentProfile) {
      showToast("Prijavite se na sajtu da biste koristili analizu.");
      return;
    }

    if (credits <= 0) {
      showToast("Nemate dovoljno kredita.");
      return;
    }

    if (!window.mockAiService?.getMockAnalysisForListing) {
      listing.analysisError = "Mock AI servis nije učitan. Osvežite ekstenziju i pokušajte ponovo.";
      renderListings();
      return;
    }

    analyzingListingId = id;
    listing.analysisError = "";
    renderListings();

    try {
      const analysis = await window.mockAiService.getMockAnalysisForListing(id);

      if (!currentDetectionResult?.is_valid_listing || !getListingById(id)?.isDetectionValid) {
        showInvalidScanState();
        return;
      }

      const updatedProfile = await consumeCredit();

      if (!updatedProfile) {
        listing.analysisError = "Krediti nisu skinuti. Pokušajte ponovo.";
        return;
      }

      listing.analysis = analysis;
      listing.unlocked = true;
      openListingId = id;
    } catch (error) {
      console.error("Failed to unlock listing analysis.", error);
      listing.analysisError =
        error instanceof Error
          ? error.message
          : "Greška pri analizi oglasa. Pokušajte ponovo.";
    } finally {
      analyzingListingId = null;
      renderListings();
    }
  };

  const toggleListing = (id) => {
    const listing = getListingById(id);

    if (!listing?.unlocked) {
      return;
    }

    openListingId = openListingId === id ? null : id;
    renderListings();
  };

  const setActionFeedback = (id, text) => {
    const feedback = document.querySelector(`#feedback-${id}`);

    if (feedback) {
      feedback.textContent = text;
    }
  };

  const getQuickPromptAnswer = (listing, promptLabel, promptQuery) => {
    const firstRisk = listing.analysis?.insights.risks[0];
    const firstHighlight = listing.analysis?.insights.highlights[0];
    const answerParts = [
      `Simuliran AI odgovor za "${promptLabel}".`,
      `Upit: ${promptQuery}`,
      firstRisk ? `Ključni rizik: ${firstRisk}` : "",
      firstHighlight ? `Glavna prednost: ${firstHighlight}` : "",
      "Koristite ovaj odgovor kao početnu procenu pre pravne i tržišne provere.",
    ];

    return answerParts.filter(Boolean).join(" ");
  };

  const toggleQuickPromptAnswer = (promptChip) => {
    const listing = getListingById(promptChip.dataset.listingId);
    const actionModule = promptChip.closest(".action-module");
    const promptAnswer = actionModule?.querySelector(".prompt-answer");

    if (!listing || !promptAnswer) {
      return;
    }

    const wasActive = promptChip.classList.contains("is-active");
    actionModule
      .querySelectorAll(".prompt-chip")
      .forEach((chip) => {
        chip.classList.remove("is-active");
        chip.setAttribute("aria-pressed", "false");
      });

    if (wasActive) {
      promptAnswer.classList.remove("is-open");
      promptAnswer.setAttribute("aria-hidden", "true");
      return;
    }

    promptChip.classList.add("is-active");
    promptChip.setAttribute("aria-pressed", "true");
    promptAnswer.textContent = getQuickPromptAnswer(
      listing,
      promptChip.dataset.promptLabel,
      promptChip.dataset.promptQuery,
    );
    promptAnswer.classList.add("is-open");
    promptAnswer.setAttribute("aria-hidden", "false");
  };

  accordion.addEventListener("click", (event) => {
    const trigger = event.target.closest(".listing-trigger");
    const unlockButton = event.target.closest(".unlock-button");
    const promptChip = event.target.closest(".prompt-chip");
    const saveButton = event.target.closest(".save-dashboard-button");

    if (unlockButton) {
      unlockListing(unlockButton.dataset.listingId);
      return;
    }

    if (trigger) {
      toggleListing(trigger.dataset.listingId);
      return;
    }

    if (promptChip) {
      toggleQuickPromptAnswer(promptChip);
      return;
    }

    if (saveButton) {
      setActionFeedback(saveButton.dataset.listingId, "Oglas je sačuvan na Dashboard.");
    }
  });

  const runListingDetection = async ({ showLoading = true } = {}) => {
    const requestId = currentScanRequestId + 1;
    currentScanRequestId = requestId;
    clearScanTimer();
    resetScanResults();
    setResultsVisible(false);
    setScanNotice("");

    if (showLoading) {
      setScannerLoading(true);
    }

    try {
      const detectionResult = await inspectActiveTabListing();

      if (requestId !== currentScanRequestId) {
        return;
      }

      if (
        !isValidDetectionPayload(detectionResult) ||
        !detectionResult.is_valid_listing ||
        !detectionResult.listing
      ) {
        showInvalidScanState();
        return;
      }

      currentDetectionResult = detectionResult;
      listings = [mapDetectionToListing(detectionResult)];
      purgeListingDom();
      renderListings();
      setPartialDataWarning(detectionResult.has_partial_data);
      setScanNotice("");
      setResultsVisible(true);
    } catch (error) {
      console.error("Listing detection failed.", error);
      showInvalidScanState();
    } finally {
      if (requestId === currentScanRequestId) {
        setScannerLoading(false);
      }
    }
  };

  scanButton.addEventListener("click", () => {
    void runListingDetection();
  });

  devToggle?.addEventListener("click", () => {
    currentScanRequestId += 1;
    clearScanTimer();
    resetScanResults();
    setScanNotice("");
    setScannerLoading(false);
    setResultsVisible(false);
  });

  const handleStorageChange = (changes, areaName) => {
    if (areaName !== "local" || !(EXTENSION_SESSION_STORAGE_KEY in changes)) {
      return;
    }

    const storedSession = changes[EXTENSION_SESSION_STORAGE_KEY].newValue ?? null;

    if (storedSession === lastStoredSessionValue) {
      return;
    }

    window.clearTimeout(authSyncTimer);
    authSyncTimer = window.setTimeout(() => {
      void applyStoredSession(storedSession, { clearOnMissing: true });
    }, 150);
  };

  const handleAuthStateChange = (_event, session) => {
    if (!session?.user?.id || session.user.id === currentUser?.id) {
      if (!session) {
        void applyStoredSession(null, { clearOnMissing: true });
      }
      return;
    }

    void applyStoredSession(
      JSON.stringify({
        currentSession: session,
        expiresAt: session.expires_at ?? null,
      }),
      { clearOnMissing: true },
    );
  };

  const authSubscription = supabaseClient?.auth?.onAuthStateChange
    ? supabaseClient.auth.onAuthStateChange(handleAuthStateChange).data.subscription
    : null;

  chrome.storage?.onChanged?.addListener(handleStorageChange);

  window.addEventListener("unload", () => {
    chrome.storage?.onChanged?.removeListener(handleStorageChange);
    authSubscription?.unsubscribe();
    unsubscribeFromProfileChanges();
    clearScanTimer();
    window.clearTimeout(authSyncTimer);
    window.clearTimeout(toastTimer);
  });

  renderListings();
  setResultsVisible(false);
  setScanNotice("");
  void initializeAuthState();
});
