const DEFAULT_CREDITS_LIMIT = 5;
const CREDIT_COST_PER_UNLOCK = 1;
const PROFILE_CACHE_STORAGE_PREFIX = "brei:profile:";
const LISTING_DETECTOR_FILE = "content/listingDetector.js";
const NO_LISTING_HEADING = "Nije detektovan oglas za analizu";
const NO_LISTING_MESSAGE =
  "Molimo vas da otvorite stranicu sa pojedinačnim oglasom na podržanim portalima (npr. Halo Oglasi) i osvežite stranicu.";
const ANALYZE_API_ERROR_MESSAGE =
  "Greška pri povezivanju sa AI serverom. Pokušajte ponovo.";
const PARTIAL_DATA_MESSAGE =
  "Upozorenje: Ovaj oglas sadrži ograničen obim informacija na samoj stranici. AI analiza je izvršena na osnovu raspoloživih podataka.";
const ANALYZE_API_URL = "https://real-estate-lac-ten.vercel.app/api/scan/analyze";

document.addEventListener("DOMContentLoaded", () => {
  const scanState = document.querySelector("#scan-state");
  const noListingState = document.querySelector("#no-listing-state");
  const resultsState = document.querySelector("#results-state");
  const scanButton = document.querySelector("#scan-button");
  const retryScanButton = document.querySelector("#retry-scan-button");
  const scanNotice = document.querySelector("#scan-notice");
  const listingsSummaryTitle = document.querySelector("#listings-summary-title");
  const summaryBadge = document.querySelector("#summary-badge");
  const partialDataWarning = document.querySelector("#partial-data-warning");
  const accordion = document.querySelector("#listings-accordion");
  const profileCard = document.querySelector("#profile-card");
  const profileAvatar = document.querySelector("#profile-avatar");
  const profileLabel = document.querySelector("#profile-label");
  const profileSubtitle = document.querySelector("#profile-subtitle");
  const profileEmail = document.querySelector("#profile-email");
  const profileAction = document.querySelector("#profile-action");
  const creditsLabel = document.querySelector("#credits-label");
  const creditsPercent = document.querySelector("#credits-percent");
  const creditsProgress = document.querySelector("#credits-progress");
  const creditsFill = document.querySelector("#credits-fill");
  const dashboardLink = document.querySelector("#dashboard-link");
  const toast = document.querySelector("#toast");
  const devToggle = document.querySelector(".dev-state-toggle");

  if (
    !scanState ||
    !noListingState ||
    !resultsState ||
    !scanButton ||
    !retryScanButton ||
    !scanNotice ||
    !listingsSummaryTitle ||
    !summaryBadge ||
    !partialDataWarning ||
    !accordion ||
    !profileCard ||
    !profileAvatar ||
    !profileLabel ||
    !profileSubtitle ||
    !profileEmail ||
    !profileAction ||
    !creditsLabel ||
    !creditsPercent ||
    !creditsProgress ||
    !creditsFill ||
    !dashboardLink ||
    !toast
  ) {
    return;
  }

  function purgeListingDom() {
    accordion.replaceChildren();
    resultsState.querySelectorAll(".listing-card").forEach((card) => {
      card.remove();
    });
  }

  purgeListingDom();
  resultsState.classList.add("is-hidden");
  resultsState.setAttribute("aria-hidden", "true");
  noListingState.classList.add("is-hidden");
  noListingState.setAttribute("aria-hidden", "true");

  const {
    EXTENSION_SESSION_STORAGE_KEY,
    SUPABASE_WEBSITE_STORAGE_KEY,
    WEBSITE_DASHBOARD_URL,
    WEBSITE_LOGIN_URL,
    WEBSITE_ORIGIN,
  } = window.breiConfig ?? {};

  const supabaseClient = window.breiSupabase;

  let currentUser = null;
  let currentProfile = null;
  let profileChannel = null;
  let profileChannelUserId = null;
  let lastStoredSessionValue;
  let lastAppliedAccessToken = null;
  let profileRequestId = 0;
  let authSyncTimer = null;
  let credits = 0;
  let creditsLimit = DEFAULT_CREDITS_LIMIT;
  let openListingId = null;
  let listings = [];
  let analyzingListingId = null;
  let scanTimer = null;
  let currentScanRequestId = 0;
  let currentDetectionResult = null;
  let toastTimer = null;

  const escapeHtml = (value) =>
    String(value ?? "").replace(/[&<>"']/g, (character) => {
      const entities = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;",
      };

      return entities[character];
    });

  const looksLikeRawCode = (value) => {
    const text = String(value ?? "").trim();

    if (!text) {
      return false;
    }

    if (/^(window\.|<script|\{)/i.test(text)) {
      return true;
    }

    if (/<script[\s>]/i.test(text) || /<\/script>/i.test(text) || /<style[\s>]/i.test(text)) {
      return true;
    }

    if (
      /\b(?:Quasar|webpackJsonp|__INITIAL_STATE__|__NEXT_DATA__|__NUXT__|__VUE__)\b/.test(
        text,
      )
    ) {
      return true;
    }

    if (text.length >= 160) {
      const codeTokens = (
        text.match(/[{};=]|=>|function\s*\(|\.prototype\b|document\.|window\./g) || []
      ).length;

      if (codeTokens >= 8) {
        return true;
      }

      const punctDensity = (text.match(/[{};]/g) || []).length / text.length;
      if (punctDensity > 0.04) {
        return true;
      }
    }

    return false;
  };

  const sanitizeDisplayText = (value, { maxLength = 2500 } = {}) => {
    const text = String(value ?? "")
      .replace(/<script[\s\S]*?<\/script>/gi, " ")
      .replace(/<style[\s\S]*?<\/style>/gi, " ")
      .replace(/<!--[\s\S]*?-->/g, " ")
      .replace(/\s+/g, " ")
      .trim();

    if (!text || looksLikeRawCode(text)) {
      return "";
    }

    if (text.length > maxLength) {
      return `${text.slice(0, maxLength).trim()}…`;
    }

    return text;
  };

  const safeDisplayHtml = (value) => {
    const cleaned = sanitizeDisplayText(value);
    return cleaned ? escapeHtml(cleaned) : "";
  };

  const formatNumber = (value) =>
    new Intl.NumberFormat("sr-RS", {
      maximumFractionDigits: 0,
    }).format(value);

  const clamp = (value, min, max) => Math.min(Math.max(value, min), max);

  const getProfileCacheKey = (userId) => `${PROFILE_CACHE_STORAGE_PREFIX}${userId}`;

  const getStoredSessionSnapshot = async () => {
    if (
      !EXTENSION_SESSION_STORAGE_KEY ||
      typeof chrome === "undefined" ||
      !chrome.storage?.local
    ) {
      return null;
    }

    const result = await chrome.storage.local.get(EXTENSION_SESSION_STORAGE_KEY);
    return result[EXTENSION_SESSION_STORAGE_KEY] ?? null;
  };

  const importSessionFromActiveWebsiteTab = async () => {
    if (
      !EXTENSION_SESSION_STORAGE_KEY ||
      !SUPABASE_WEBSITE_STORAGE_KEY ||
      !WEBSITE_ORIGIN ||
      typeof chrome === "undefined" ||
      !chrome.tabs?.query ||
      !chrome.scripting?.executeScript ||
      !chrome.storage?.local
    ) {
      return null;
    }

    try {
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const websiteTabs = await chrome.tabs.query({ url: `${WEBSITE_ORIGIN}/*` });
      const candidateTabs = [
        activeTab,
        ...websiteTabs.filter((tab) => tab.id !== activeTab?.id),
      ].filter(
        (tab) =>
          tab?.id &&
          (tab.url === WEBSITE_ORIGIN || tab.url?.startsWith(`${WEBSITE_ORIGIN}/`)),
      );

      for (const tab of candidateTabs) {
        const [injectionResult] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          args: [SUPABASE_WEBSITE_STORAGE_KEY],
          func: (storageKey) => {
          const base64CookiePrefix = "base64-";

          const decodeBase64Url = (value) => {
            const base64 = value.replace(/-/g, "+").replace(/_/g, "/");
            const padded = base64.padEnd(
              base64.length + ((4 - (base64.length % 4)) % 4),
              "=",
            );
            return decodeURIComponent(
              Array.from(atob(padded), (character) =>
                `%${character.charCodeAt(0).toString(16).padStart(2, "0")}`,
              ).join(""),
            );
          };

          const normalizeSessionValue = (value) => {
            if (!value) {
              return null;
            }

            if (value.startsWith(base64CookiePrefix)) {
              return decodeBase64Url(value.slice(base64CookiePrefix.length));
            }

            return value;
          };

          const readChunkedCookie = (cookies, key) => {
            if (cookies[key]) {
              return cookies[key];
            }

            const chunks = [];

            for (let index = 0; index < 10; index += 1) {
              const chunk = cookies[`${key}.${index}`];

              if (!chunk) {
                break;
              }

              chunks.push(chunk);
            }

            return chunks.length > 0 ? chunks.join("") : null;
          };

          const readCookies = () =>
            document.cookie
              .split(";")
              .map((cookie) => cookie.trim())
              .filter(Boolean)
              .reduce((cookies, cookie) => {
                const separatorIndex = cookie.indexOf("=");

                if (separatorIndex === -1) {
                  return cookies;
                }

                cookies[decodeURIComponent(cookie.slice(0, separatorIndex))] =
                  decodeURIComponent(cookie.slice(separatorIndex + 1));
                return cookies;
              }, {});

          const localStorageSession = window.localStorage.getItem(storageKey);

          if (localStorageSession) {
            return localStorageSession;
          }

          const cookies = readCookies();
          return normalizeSessionValue(readChunkedCookie(cookies, storageKey));
          },
        });

        const sessionValue =
          typeof injectionResult?.result === "string" ? injectionResult.result : null;

        if (sessionValue) {
          await chrome.storage.local.set({ [EXTENSION_SESSION_STORAGE_KEY]: sessionValue });
          return sessionValue;
        }
      }

      if (candidateTabs.length > 0) {
        await chrome.storage.local.remove(EXTENSION_SESSION_STORAGE_KEY);
      }

      return null;
    } catch (error) {
      console.error("[Extension Auth] Could not import session from website tab.", error);
      return null;
    }
  };

  const getCachedProfile = async (userId) => {
    if (!userId || typeof chrome === "undefined" || !chrome.storage?.local) {
      return null;
    }

    try {
      const cacheKey = getProfileCacheKey(userId);
      const result = await chrome.storage.local.get(cacheKey);
      return result[cacheKey] ?? null;
    } catch (error) {
      console.error("[Extension Auth] Could not read cached profile.", error);
      return null;
    }
  };

  const setCachedProfile = async (userId, profile) => {
    if (!userId || !profile || typeof chrome === "undefined" || !chrome.storage?.local) {
      return;
    }

    try {
      await chrome.storage.local.set({ [getProfileCacheKey(userId)]: profile });
    } catch (error) {
      console.error("[Extension Auth] Could not cache profile.", error);
    }
  };

  const parseStoredSession = (storedSession) => {
    if (!storedSession) {
      return null;
    }

    try {
      const parsedSession =
        typeof storedSession === "string" ? JSON.parse(storedSession) : storedSession;
      const session = parsedSession.currentSession || parsedSession.session || parsedSession;

      if (session?.access_token && session?.refresh_token && session?.user) {
        return {
          session,
          user: session.user,
          accessToken: session.access_token,
          refreshToken: session.refresh_token,
        };
      }
    } catch (error) {
      console.error("[Extension Auth] Stored session could not be parsed:", error);
    }

    return null;
  };

  const restoreSessionIfChanged = async (auth) => {
    if (!auth?.accessToken || !auth?.refreshToken || !supabaseClient?.auth?.setSession) {
      return;
    }

    if (auth.accessToken === lastAppliedAccessToken) {
      return;
    }

    const { error } = await supabaseClient.auth.setSession({
      access_token: auth.accessToken,
      refresh_token: auth.refreshToken,
    });

    if (error) {
      throw error;
    }

    lastAppliedAccessToken = auth.accessToken;
  };

  const getNumberValue = (...values) => {
    const value = values.find((candidate) => Number.isFinite(Number(candidate)));
    return value === undefined ? 0 : Number(value);
  };

  const getDisplayName = (profile, user) => {
    const fullName = (profile?.fullname || profile?.full_name || profile?.name)?.trim();
    return fullName || user?.email || "Korisnik";
  };

  const getInitials = (value) => {
    const normalized = String(value ?? "")
      .replace(/@.*/, "")
      .trim();

    if (!normalized) {
      return "BR";
    }

    const parts = normalized.split(/\s+/).filter(Boolean);

    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
    }

    return normalized.slice(0, 2).toUpperCase();
  };

  const getTierLabel = (profile) => {
    const status = profile?.subscription_status ?? "trial";
    const labels = {
      active: "Active subscriber",
      canceled: "Subscription canceled",
      expired: "Subscription expired",
      trial: "Beta Access User",
    };

    return labels[status] ?? status.replace(/_/g, " ");
  };

  const setProfileStateClass = (state) => {
    profileCard.classList.toggle("is-loading", state === "loading");
    profileCard.classList.toggle("is-unauthenticated", state === "unauthenticated");
    profileCard.classList.toggle("is-error", state === "error");
  };

  const showToast = (message) => {
    window.clearTimeout(toastTimer);
    toast.textContent = message;
    toast.classList.add("is-visible");
    toast.setAttribute("aria-hidden", "false");

    toastTimer = window.setTimeout(() => {
      toast.classList.remove("is-visible");
      toast.setAttribute("aria-hidden", "true");
    }, 3200);
  };

  const updateCredits = () => {
    const safeLimit = Math.max(creditsLimit, 1);
    const percentage = clamp(Math.round((credits / safeLimit) * 100), 0, 100);

    creditsLabel.textContent = `Credits: ${credits} / ${creditsLimit}`;
    creditsPercent.textContent = `${percentage}%`;
    creditsProgress.setAttribute("aria-label", `Krediti: ${credits} od ${creditsLimit}`);
    creditsFill.style.width = `${percentage}%`;
  };

  const renderUnauthenticatedProfile = () => {
    currentUser = null;
    currentProfile = null;
    credits = 0;
    creditsLimit = DEFAULT_CREDITS_LIMIT;
    setProfileStateClass("unauthenticated");
    profileAvatar.textContent = "BR";
    profileLabel.textContent = "Niste prijavljeni";
    profileSubtitle.textContent = "Kliknite Prijava da povežete nalog.";
    profileEmail.textContent = "";
    profileAction.textContent = "Prijava";
    profileAction.href = WEBSITE_LOGIN_URL || "#";
    dashboardLink.href = WEBSITE_DASHBOARD_URL || "#";
    updateCredits();
  };

  const renderAuthenticatedProfile = (profile, user) => {
    const displayName = getDisplayName(profile, user);
    credits = clamp(
      Math.floor(getNumberValue(profile?.credits_remaining, profile?.credits)),
      0,
      Number.MAX_SAFE_INTEGER,
    );
    creditsLimit = Math.max(
      Math.floor(getNumberValue(profile?.credits_limit, profile?.credits_total, DEFAULT_CREDITS_LIMIT)),
      1,
    );

    setProfileStateClass("authenticated");
    profileAvatar.textContent = getInitials(displayName);
    profileLabel.textContent = displayName;
    profileSubtitle.textContent = getTierLabel(profile);
    profileEmail.textContent = user?.email || profile?.email || "";
    profileAction.textContent = "Upgrade";
    profileAction.href = WEBSITE_DASHBOARD_URL || "#";
    dashboardLink.href = WEBSITE_DASHBOARD_URL || "#";
    updateCredits();
  };

  const unsubscribeFromProfileChanges = () => {
    if (!profileChannel) {
      profileChannelUserId = null;
      return;
    }

    supabaseClient.removeChannel(profileChannel);
    profileChannel = null;
    profileChannelUserId = null;
  };

  const subscribeToProfileChanges = (userId) => {
    if (!userId || profileChannelUserId === userId) {
      return;
    }

    unsubscribeFromProfileChanges();
    profileChannelUserId = userId;

    profileChannel = supabaseClient
      .channel(`profile-credit-${userId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          filter: `id=eq.${userId}`,
          schema: "public",
          table: "profiles",
        },
        (payload) => {
          if (currentUser?.id !== userId || payload.new?.id !== userId) {
            console.warn("[Extension Auth] Ignored profile update for inactive user.", {
              activeUserId: currentUser?.id ?? null,
              subscribedUserId: userId,
              profileUserId: payload.new?.id ?? null,
            });
            return;
          }

          currentProfile = payload.new;
          void setCachedProfile(userId, currentProfile);
          renderAuthenticatedProfile(currentProfile, currentUser);
        },
      )
      .subscribe((status, error) => {
        if (error) {
          console.error("Supabase profile realtime subscription error.", error);
        }

        if (status === "CHANNEL_ERROR") {
          console.error("Supabase profile realtime channel failed.");
        }
      });
  };

  const fetchAndRenderProfile = async (user, requestId = ++profileRequestId) => {
    if (!user?.id || !supabaseClient?.from) {
      return null;
    }

    try {
      const { data, error } = await supabaseClient
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .maybeSingle();

      if (error) {
        throw error;
      }

      if (requestId !== profileRequestId || currentUser?.id !== user.id) {
        return null;
      }

      if (!data) {
        console.warn("[Extension Auth] No profile row found for active user.", user.id);
        return null;
      }

      currentProfile = data;
      await setCachedProfile(user.id, data);
      renderAuthenticatedProfile(currentProfile, currentUser);
      subscribeToProfileChanges(user.id);
      return data;
    } catch (error) {
      console.error("[Extension Profile Fetch Error:]", error);
      if (currentUser?.id === user.id) {
        renderAuthenticatedProfile(currentProfile, currentUser);
      }
      return null;
    }
  };

  const applyStoredSession = async (storedSession, { clearOnMissing = false } = {}) => {
    const auth = parseStoredSession(storedSession);

    if (!auth?.user?.id) {
      lastStoredSessionValue = storedSession ?? null;
      lastAppliedAccessToken = null;
      profileRequestId += 1;
      unsubscribeFromProfileChanges();

      if (clearOnMissing || !currentUser) {
        renderUnauthenticatedProfile();
      }

      return null;
    }

    lastStoredSessionValue = storedSession;
    const cachedProfile = await getCachedProfile(auth.user.id);
    const immediateProfile =
      cachedProfile ?? (currentUser?.id === auth.user.id ? currentProfile : null);

    currentUser = auth.user;
    currentProfile = immediateProfile;
    renderAuthenticatedProfile(currentProfile, currentUser);

    try {
      await restoreSessionIfChanged(auth);
    } catch (error) {
      console.error("[Extension Auth] Stored session restore failed:", error);
      return currentProfile;
    }

    return fetchAndRenderProfile(currentUser);
  };

  const initializeAuthState = async () => {
    try {
      await importSessionFromActiveWebsiteTab();
      const storedSession = await getStoredSessionSnapshot();

      if (storedSession) {
        await applyStoredSession(storedSession, { clearOnMissing: true });
        return;
      }

      const { data, error } = supabaseClient?.auth?.getSession
        ? await supabaseClient.auth.getSession()
        : { data: null, error: null };

      if (error) {
        throw error;
      }

      if (data?.session) {
        await applyStoredSession(
          JSON.stringify({
            currentSession: data.session,
            expiresAt: data.session.expires_at ?? null,
          }),
          { clearOnMissing: true },
        );
        return;
      }

      renderUnauthenticatedProfile();
    } catch (error) {
      console.error("[Extension Auth] Initial auth state failed:", error);
      if (currentUser) {
        renderAuthenticatedProfile(currentProfile, currentUser);
      } else {
        renderUnauthenticatedProfile();
      }
    }
  };

  const setScannerLoading = (isLoading) => {
    scanButton.classList.toggle("is-loading", isLoading);
    scanButton.setAttribute("aria-busy", String(isLoading));
    retryScanButton.classList.toggle("is-loading", isLoading);
    retryScanButton.setAttribute("aria-busy", String(isLoading));

    if (isLoading) {
      scanButton.disabled = true;
      retryScanButton.disabled = true;
      return;
    }

    const isNoListingPanel = !noListingState.classList.contains("is-hidden");
    scanButton.disabled = isNoListingPanel;
    retryScanButton.disabled = false;
  };

  const clearScanTimer = () => {
    if (scanTimer) {
      window.clearTimeout(scanTimer);
      scanTimer = null;
    }
  };

  const setScanNotice = (message = "") => {
    scanNotice.textContent = message;
    scanNotice.classList.toggle("is-hidden", !message);
    scanNotice.setAttribute("aria-hidden", String(!message));
  };

  const setPartialDataWarning = (isVisible) => {
    partialDataWarning.textContent = isVisible ? PARTIAL_DATA_MESSAGE : "";
    partialDataWarning.classList.toggle("is-hidden", !isVisible);
    partialDataWarning.setAttribute("aria-hidden", String(!isVisible));
  };

  const resetScanResults = () => {
    currentDetectionResult = null;
    listings = [];
    openListingId = null;
    analyzingListingId = null;
    setPartialDataWarning(false);
    purgeListingDom();
    renderListings();
  };

  const setActivePanel = (panel) => {
    const showScan = panel === "scan";
    const showNoListing = panel === "no-listing";
    const showResults = panel === "results";

    scanState.classList.toggle("is-hidden", !showScan);
    noListingState.classList.toggle("is-hidden", !showNoListing);
    resultsState.classList.toggle("is-hidden", !showResults);

    scanState.setAttribute("aria-hidden", String(!showScan));
    noListingState.setAttribute("aria-hidden", String(!showNoListing));
    resultsState.setAttribute("aria-hidden", String(!showResults));

    scanButton.disabled = showNoListing;
    retryScanButton.disabled = false;

    const resultsActive = showResults || showNoListing;
    devToggle?.classList.toggle("is-active", resultsActive);
    devToggle?.setAttribute("aria-pressed", String(resultsActive));
  };

  const setResultsVisible = (isVisible) => {
    setActivePanel(isVisible ? "results" : "scan");
  };

  const updateListingsSummary = () => {
    listingsSummaryTitle.textContent = "Pronađen pojedinačni oglas na stranici";
    summaryBadge.textContent = listings.length === 1 ? "1 aktivan" : "0 aktivnih";
  };

  const isNoListingsFoundResult = (result) =>
    !result ||
    result.type === "NO_LISTINGS_FOUND" ||
    (Array.isArray(result.listings) && result.listings.length === 0 && result.is_valid_listing !== true) ||
    result.is_valid_listing === false ||
    !result.listing;

  const isValidDetectionPayload = (result) => {
    if (!result || result.type === "NO_LISTINGS_FOUND") {
      return false;
    }

    const signals = result?.detection?.signals;
    const passesStrongJsonLdRule = signals?.has_strong_json_ld === true;
    const passesDomHeuristicRule =
      signals?.has_price === true &&
      signals?.has_explicit_dom_area === true &&
      signals?.has_property_context === true;
    const passesListingRules =
      signals?.is_collection_like === false &&
      signals?.is_generic_blocked_page === false &&
      (passesStrongJsonLdRule || passesDomHeuristicRule);

    return (
      (result.type === "LISTING_FOUND" || result.schema_version === 1) &&
      result.is_valid_listing === true &&
      typeof result.has_partial_data === "boolean" &&
      Number.isInteger(result.completeness_score) &&
      Array.isArray(result.missing_fields) &&
      result.detection &&
      typeof result.detection.method === "string" &&
      signals &&
      typeof result.listing === "object" &&
      result.listing !== null &&
      passesListingRules
    );
  };

  const formatDetectedPrice = (price) => {
    if (price?.raw) {
      return price.raw;
    }

    if (!Number.isFinite(price?.value)) {
      return "Cena nije pronađena";
    }

    const currencyLabels = {
      EUR: "€",
      USD: "$",
      GBP: "£",
      RSD: "RSD",
    };

    return `${formatNumber(price.value)} ${currencyLabels[price.currency] ?? price.currency ?? ""}`.trim();
  };

  const createDetectedListingId = (listing) => {
    const source = listing?.listing_url || `${listing?.portal_name ?? "detected"}-${Date.now()}`;
    let hash = 0;

    for (let index = 0; index < source.length; index += 1) {
      hash = (hash * 31 + source.charCodeAt(index)) >>> 0;
    }

    return `detected-${hash.toString(36)}`;
  };

  const mapDetectionToListing = (detectionResult) => {
    const detectedListing = detectionResult.listing;

    return {
      id: createDetectedListingId(detectedListing),
      title: detectedListing.title || "Naslov oglasa nije pronađen",
      location: detectedListing.location || "Lokacija nije pronađena",
      price: formatDetectedPrice(detectedListing.price),
      unlocked: false,
      detection: detectionResult,
      hasPartialData: detectionResult.has_partial_data,
      isDetectionValid: detectionResult.is_valid_listing,
    };
  };

  const getActiveTab = async () => {
    if (typeof chrome === "undefined" || !chrome.tabs?.query) {
      return null;
    }

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab ?? null;
  };

  const canInspectTab = (tab) => Boolean(tab?.id && /^https?:\/\//i.test(tab.url ?? ""));

  const inspectActiveTabListing = async () => {
    if (typeof chrome === "undefined" || !chrome.scripting?.executeScript) {
      return null;
    }

    const tab = await getActiveTab();

    if (!canInspectTab(tab)) {
      return null;
    }

    const [injectionResult] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: [LISTING_DETECTOR_FILE],
    });

    return injectionResult?.result ?? null;
  };

  const showNoListingWarningState = () => {
    resetScanResults();
    setScanNotice("");
    setPartialDataWarning(false);
    setActivePanel("no-listing");
  };

  const showInvalidScanState = () => {
    showNoListingWarningState();
  };

  const getListingById = (id) => listings.find((listing) => listing.id === id);

  const ANALYSIS_FIELD_LABELS = {
    summary: "SAŽETAK",
    valuation: "PROCENA VREDNOSTI",
    market_assessment: "Tržišna procena",
    reasoning: "Obrazloženje",
    recommended_checks: "Preporučene provere",
    target_discount_pct: "Ciljani popust",
    target_discount_percentage: "Ciljani popust",
    leverage_points: "Aduti za pregovaranje",
    cost_breakdown: "Struktura troškova",
    red_flags: "Upozorenja i rizici",
    risks: "Upozorenja i rizici",
    costs: "Troškovi",
    legal_checks: "PRAVNE PROVERE",
    legal_check: "Pravna provera",
    technical_checks: "TEHNIČKE PROVERE",
    technical_check: "Tehnička provera",
    legal_technical_checks: "PRAVNE I TEHNIČKE PROVERE",
    negotiation_strategy: "STRATEGIJA PREGOVORA",
    negotiation_strategy_lines: "STRATEGIJA PREGOVORA",
    dynamic_faq: "ČESTA PITANJA",
    dynamic_quick_prompts: "ČESTA PITANJA",
    faq: "ČESTA PITANJA",
    question: "Pitanje",
    answer: "Odgovor",
    financials: "FINANSIJSKI PREGLED",
    deal_score: "AI OCENA PONUDE",
    highlights: "PREDNOSTI",
  };

  const formatAnalysisLabel = (key) => {
    const normalizedKey = String(key ?? "")
      .trim()
      .toLowerCase()
      .replace(/[\s-]+/g, "_");

    return (
      ANALYSIS_FIELD_LABELS[normalizedKey] ||
      normalizedKey
      .replace(/_/g, " ")
      .replace(/^\p{L}/u, (letter) => letter.toUpperCase())
    );
  };

  const isAnalysisObject = (value) =>
    Boolean(value) && typeof value === "object" && !Array.isArray(value);

  const formatScalarDisplay = (value) => {
    if (value === null || value === undefined || value === "") {
      return "Podatak nije naveden";
    }

    if (typeof value === "boolean") {
      return value ? "Da" : "Ne";
    }

    if (typeof value === "string") {
      return sanitizeDisplayText(value) || "Podatak nije naveden";
    }

    return String(value);
  };

  const isScalarValue = (value) =>
    value === null ||
    value === undefined ||
    typeof value === "string" ||
    typeof value === "number" ||
    typeof value === "boolean";

  const renderKvRow = (label, valueHtml, { accent = false } = {}) => `
    <div class="kv-row">
      <span class="kv-label">${escapeHtml(label)}</span>
      <span class="kv-value ${accent ? "kv-value-accent" : ""}">${valueHtml}</span>
    </div>
  `;

  const renderKvTable = (rowsHtml) =>
    rowsHtml ? `<div class="kv-table">${rowsHtml}</div>` : "";

  const renderSectionCard = (title, bodyHtml, extraClass = "") => {
    if (!bodyHtml) {
      return "";
    }

    return `
      <section class="analysis-module ${extraClass}" aria-label="${escapeHtml(title)}">
        <h3 class="section-heading">${escapeHtml(title)}</h3>
        ${bodyHtml}
      </section>
    `;
  };

  const renderStructuredValue = (value, key = "") => {
    if (value === null || value === undefined || value === "") {
      return '<p class="muted-label">Nema dostupnih podataka.</p>';
    }

    if (Array.isArray(value)) {
      if (value.length === 0) {
        return '<p class="muted-label">Nema izdvojenih stavki.</p>';
      }

      const allScalars = value.every(isScalarValue);

      if (allScalars) {
        return renderKvTable(
          value
            .map((item, index) =>
              renderKvRow(`${index + 1}.`, escapeHtml(formatScalarDisplay(item))),
            )
            .join(""),
        );
      }

      return `
        <div class="nested-stack">
          ${value
            .map(
              (item, index) => `
                <div class="nested-block">
                  ${
                    isAnalysisObject(item)
                      ? renderStructuredValue(item, `${key}_${index}`)
                      : `<p class="score-caption">${escapeHtml(formatScalarDisplay(item))}</p>`
                  }
                </div>
              `,
            )
            .join("")}
        </div>
      `;
    }

    if (typeof value === "object") {
      const entries = Object.entries(value);
      const scalarEntries = entries.filter(([, nestedValue]) => isScalarValue(nestedValue));
      const complexEntries = entries.filter(([, nestedValue]) => !isScalarValue(nestedValue));

      return `
        ${
          scalarEntries.length > 0
            ? renderKvTable(
                scalarEntries
                  .map(([nestedKey, nestedValue]) =>
                    renderKvRow(
                      formatAnalysisLabel(nestedKey),
                      escapeHtml(formatScalarDisplay(nestedValue)),
                      {
                        accent:
                          nestedKey.includes("price") ||
                          nestedKey.includes("score") ||
                          nestedKey.includes("discount"),
                      },
                    ),
                  )
                  .join(""),
              )
            : ""
        }
        ${complexEntries
          .map(
            ([nestedKey, nestedValue]) => `
              <div class="nested-block">
                <p class="nested-heading">${escapeHtml(formatAnalysisLabel(nestedKey))}</p>
                ${renderStructuredValue(nestedValue, nestedKey)}
              </div>
            `,
          )
          .join("")}
      `;
    }

    const displayValue = formatScalarDisplay(value);

    if (displayValue === "Podatak nije naveden" && looksLikeRawCode(value)) {
      return "";
    }

    return `<p class="${key === "summary" ? "score-caption" : "muted-label"}">${escapeHtml(displayValue)}</p>`;
  };

  const renderAnalysisModule = ([key, value]) =>
    renderSectionCard(formatAnalysisLabel(key), renderStructuredValue(value, key));

  const firstAvailable = (...values) =>
    values.find((value) => value !== null && value !== undefined && value !== "");

  const collectTextItems = (value) => {
    if (value === null || value === undefined || value === "") {
      return [];
    }

    if (Array.isArray(value)) {
      return value.flatMap(collectTextItems);
    }

    if (isAnalysisObject(value)) {
      return Object.values(value).flatMap(collectTextItems);
    }

    if (typeof value === "string") {
      const cleaned = sanitizeDisplayText(value);
      return cleaned ? [cleaned] : [];
    }

    const asText = String(value);
    return looksLikeRawCode(asText) ? [] : [asText];
  };

  const renderMetricDisplay = (value, key) => {
    if (value === null || value === undefined || value === "") {
      return "—";
    }

    if (!Number.isFinite(Number(value))) {
      return escapeHtml(value);
    }

    const numericValue = Number(value);

    if (key.includes("percentage") || key.includes("pct")) {
      return `${numericValue > 0 ? "+" : ""}${numericValue}%`;
    }

    if (key.includes("price") || key.includes("cost")) {
      return `${formatNumber(numericValue)} €`;
    }

    return escapeHtml(numericValue);
  };

  const getPriceMetrics = (analysis) => {
    const financials = isAnalysisObject(analysis.financials) ? analysis.financials : {};
    const valuation = isAnalysisObject(analysis.valuation) ? analysis.valuation : {};

    return {
      pricePerSqm: firstAvailable(financials.price_per_sqm, valuation.price_per_sqm),
      locationAverage: firstAvailable(
        financials.location_average_price_per_sqm,
        valuation.location_average_price_per_sqm,
      ),
      priceDifference: firstAvailable(
        financials.price_difference_percentage,
        valuation.price_difference_percentage,
      ),
    };
  };

  const isUsableMetric = (key, value) => {
    if (value === undefined || value === null || value === "") {
      return false;
    }

    if (
      typeof value === "number" &&
      value === 0 &&
      (key === "price_per_sqm" || key === "location_average_price_per_sqm")
    ) {
      return false;
    }

    return true;
  };

  const renderPriceBanner = (listing, analysis) => {
    const { pricePerSqm } = getPriceMetrics(analysis);
    const hasPricePerSqm = isUsableMetric("price_per_sqm", pricePerSqm);
    const pricePerSqmLabel = hasPricePerSqm
      ? renderMetricDisplay(pricePerSqm, "price_per_sqm")
      : "—";

    return `
      <section class="price-hero" aria-label="Cena i cena po kvadratu">
        <div class="price-hero-main">
          <span class="price-hero-label">Ukupna cena</span>
          <strong class="price-hero-value">${escapeHtml(listing.price || "—")}</strong>
        </div>
        <span class="price-sqm-badge" title="Cena po m²">${pricePerSqmLabel}</span>
      </section>
    `;
  };

  const renderContactCard = (listing, analysis) => {
    const detectedListing = listing?.detection?.listing ?? {};
    const financials = isAnalysisObject(analysis.financials) ? analysis.financials : {};
    const contact = isAnalysisObject(analysis.contact)
      ? analysis.contact
      : isAnalysisObject(analysis.seller_contact)
        ? analysis.seller_contact
        : {};
    const phone = firstAvailable(
      contact.phone,
      contact.phone_number,
      analysis.phone,
      analysis.phone_number,
      detectedListing.phone,
      detectedListing.phone_number,
    );
    const agency = firstAvailable(
      contact.agency,
      contact.agency_name,
      analysis.agency,
      analysis.agency_name,
      financials.seller_type,
      detectedListing.agency,
      detectedListing.agency_name,
    );
    const ownerName = firstAvailable(
      contact.owner_name,
      contact.name,
      analysis.owner_name,
      detectedListing.owner_name,
    );

    return renderSectionCard(
      "Informacije o nekretnini",
      renderKvTable(
        [
          renderKvRow("Ime / agencija", escapeHtml(agency || "Podatak nije naveden")),
          renderKvRow("Vlasnik", escapeHtml(ownerName || "Podatak nije naveden")),
          renderKvRow("Telefon", escapeHtml(phone || "Nije pronađen"), { accent: true }),
          renderKvRow("Lokacija", escapeHtml(listing.location || "Podatak nije naveden")),
          renderKvRow("Naslov", escapeHtml(listing.title || "Podatak nije naveden")),
        ].join(""),
      ),
      "contact-module",
    );
  };

  const renderFinancialsSection = (analysis) => {
    const financials = isAnalysisObject(analysis.financials) ? analysis.financials : {};
    const valuation = isAnalysisObject(analysis.valuation) ? analysis.valuation : {};
    const costBreakdown = isAnalysisObject(analysis.cost_breakdown)
      ? analysis.cost_breakdown
      : isAnalysisObject(analysis.costs)
        ? analysis.costs
        : {};
    const { locationAverage, priceDifference } = getPriceMetrics(analysis);
    const skipKeys = new Set([
      "price_per_sqm",
      "location_average_price_per_sqm",
      "price_difference_percentage",
    ]);

    const rows = [];

    if (isUsableMetric("location_average_price_per_sqm", locationAverage)) {
      rows.push(
        renderKvRow(
          "Prosek lokacije",
          renderMetricDisplay(locationAverage, "location_average_price_per_sqm"),
        ),
      );
    }

    if (isUsableMetric("price_difference_percentage", priceDifference)) {
      const numericDiff = Number(priceDifference);
      const accentClass =
        Number.isFinite(numericDiff) && numericDiff < 0 ? "kv-value-positive" : "kv-value-warning";

      rows.push(
        `<div class="kv-row"><span class="kv-label">Razlika od proseka</span><span class="kv-value ${accentClass}">${renderMetricDisplay(priceDifference, "price_difference_percentage")}</span></div>`,
      );
    }

    const mergeScalarEntries = (source) => {
      Object.entries(source).forEach(([key, value]) => {
        if (skipKeys.has(key) || !isScalarValue(value)) {
          return;
        }

        if (value === null || value === undefined || value === "") {
          return;
        }

        rows.push(
          renderKvRow(
            formatAnalysisLabel(key),
            Number.isFinite(Number(value)) &&
              (key.includes("price") || key.includes("cost") || key.includes("fee"))
              ? renderMetricDisplay(value, key)
              : escapeHtml(formatScalarDisplay(value)),
            {
              accent: key.includes("price") || key.includes("discount") || key.includes("score"),
            },
          ),
        );
      });
    };

    mergeScalarEntries(financials);
    mergeScalarEntries(valuation);
    mergeScalarEntries(costBreakdown);

    const complexBlocks = [financials, valuation, costBreakdown]
      .flatMap((source) =>
        Object.entries(source).filter(([, value]) => !isScalarValue(value) && value !== null),
      )
      .map(
        ([key, value]) => `
          <div class="nested-block">
            <p class="nested-heading">${escapeHtml(formatAnalysisLabel(key))}</p>
            ${renderStructuredValue(value, key)}
          </div>
        `,
      )
      .join("");

    if (rows.length === 0 && !complexBlocks) {
      return "";
    }

    return renderSectionCard(
      "Troškovi i procene",
      `${renderKvTable(rows.join(""))}${complexBlocks}`,
      "financials-module",
    );
  };

  const renderDealScore = (analysis) => {
    if (!isAnalysisObject(analysis.deal_score)) {
      return "";
    }

    const score = clamp(Number(analysis.deal_score.score) || 0, 0, 10);

    return renderSectionCard(
      "AI ocena ponude",
      `
        <div class="module-title-row">
          <span class="kv-label">Ocena</span>
          <strong class="deal-score-value">${escapeHtml(score.toFixed(1))} / 10</strong>
        </div>
        <div class="progress-track score-track" aria-label="Ocena ${escapeHtml(String(score))} od 10">
          <div class="progress-fill score-fill" style="width: ${score * 10}%"></div>
        </div>
        ${
          sanitizeDisplayText(analysis.deal_score.verdict)
            ? `<p class="score-caption">${safeDisplayHtml(analysis.deal_score.verdict)}</p>`
            : ""
        }
      `,
      "deal-score-module",
    );
  };

  const renderAlertCards = (analysis) => {
    const insights = isAnalysisObject(analysis.insights) ? analysis.insights : {};
    const risks = collectTextItems(
      firstAvailable(analysis.red_flags, analysis.risks, insights.risks),
    );
    const highlights = collectTextItems(
      firstAvailable(analysis.highlights, insights.highlights, insights.pros),
    );

    const risksBody =
      risks.length > 0
        ? `<div class="alert-list">${risks
            .map(
              (risk) => `
                <article class="alert-card">
                  <span aria-hidden="true">!</span>
                  <p>${safeDisplayHtml(risk)}</p>
                </article>
              `,
            )
            .join("")}</div>`
        : '<p class="muted-label empty-state">Nisu izdvojena posebna upozorenja.</p>';

    const highlightsBody =
      highlights.length > 0
        ? renderKvTable(
            highlights
              .map((item, index) =>
                renderKvRow(`Prednost ${index + 1}`, safeDisplayHtml(item), { accent: true }),
              )
              .join(""),
          )
        : "";

    return `
      ${renderSectionCard("Upozorenja i rizici", risksBody, "risk-module")}
      ${renderSectionCard("Prednosti", highlightsBody, "highlights-module")}
    `;
  };

  const renderRecommendedChecks = (analysis) => {
    const checks = [
      ...collectTextItems(analysis.recommended_checks),
      ...collectTextItems(analysis.legal_checks),
      ...collectTextItems(analysis.technical_checks),
      ...collectTextItems(analysis.legal_technical_checks),
    ];

    const body =
      checks.length > 0
        ? `<div class="check-list">${[...new Set(checks)]
            .map(
              (check, index) => `
                <label class="check-item">
                  <input type="checkbox" data-check-index="${index}">
                  <span class="custom-checkbox" aria-hidden="true"></span>
                  <span>${safeDisplayHtml(check)}</span>
                </label>
              `,
            )
            .join("")}</div>`
        : '<p class="muted-label empty-state">Nema dodatnih preporučenih provera.</p>';

    return renderSectionCard("Preporučene provere", body, "checks-module");
  };

  const renderAccordionItems = (items, listingId, prefix) => {
    if (items.length === 0) {
      return "";
    }

    return `
      <div class="faq-list" data-accordion-group="${prefix}">
        ${items
          .map(
            (item, index) => `
              <article class="faq-item">
                <button
                  class="faq-question"
                  type="button"
                  aria-expanded="false"
                  aria-controls="${prefix}-${listingId}-${index}"
                >
                  <span class="faq-question-text">${safeDisplayHtml(item.question) || escapeHtml("Pitanje")}</span>
                  <span class="faq-chevron" aria-hidden="true">
                    <svg viewBox="0 0 24 24" focusable="false">
                      <path d="m6 9 6 6 6-6"></path>
                    </svg>
                  </span>
                </button>
                <div class="faq-answer" id="${prefix}-${listingId}-${index}" hidden>
                  ${safeDisplayHtml(item.answer) || escapeHtml("Odgovor nije dostupan.")}
                </div>
              </article>
            `,
          )
          .join("")}
      </div>
    `;
  };

  const normalizeFaqItems = (analysis) => {
    const source = firstAvailable(
      analysis.dynamic_faq,
      analysis.faq,
      analysis.dynamic_quick_prompts,
    );

    if (!source) {
      return [];
    }

    const items = Array.isArray(source) ? source : [source];

    return items
      .map((item) => {
        if (typeof item === "string") {
          return { question: item, answer: "Odgovor nije dostupan." };
        }

        if (!isAnalysisObject(item)) {
          return null;
        }

        return {
          question: firstAvailable(item.question, item.label, item.title, item.prompt_query),
          answer: firstAvailable(item.answer, item.response, item.content, item.prompt_query),
        };
      })
      .map((item) => ({
        question: sanitizeDisplayText(item.question, { maxLength: 400 }),
        answer: sanitizeDisplayText(item.answer, { maxLength: 2500 }) || "Odgovor nije dostupan.",
      }))
      .filter((item) => item.question);
  };

  const normalizeNegotiationItems = (analysis) => {
    const insights = isAnalysisObject(analysis.insights) ? analysis.insights : {};
    const items = [];
    const targetDiscount = firstAvailable(
      analysis.target_discount_pct,
      analysis.target_discount_percentage,
    );

    if (targetDiscount !== undefined && targetDiscount !== null && targetDiscount !== "") {
      const numericDiscount = Number(targetDiscount);
      const discountLabel = Number.isFinite(numericDiscount)
        ? `${numericDiscount > 0 ? "+" : ""}${numericDiscount}%`
        : String(targetDiscount);

      items.push({
        question: "Ciljani popust",
        answer: discountLabel,
      });
    }

    const leverage = firstAvailable(analysis.leverage_points, insights.highlights);
    collectTextItems(leverage).forEach((point, index) => {
      items.push({
        question: `Adut za pregovaranje ${index + 1}`,
        answer: point,
      });
    });

    const strategy = firstAvailable(
      analysis.negotiation_strategy,
      analysis.negotiation_strategy_lines,
    );

    if (Array.isArray(strategy)) {
      strategy.forEach((item, index) => {
        if (typeof item === "string") {
          items.push({
            question: `Strategija ${index + 1}`,
            answer: item,
          });
          return;
        }

        if (isAnalysisObject(item)) {
          items.push({
            question: firstAvailable(item.title, item.question, item.label, `Strategija ${index + 1}`),
            answer: firstAvailable(item.answer, item.content, item.description, item.tip, item.text),
          });
        }
      });
    } else if (typeof strategy === "string" && strategy.trim()) {
      items.push({
        question: "Strategija pregovaranja",
        answer: strategy,
      });
    } else if (isAnalysisObject(strategy)) {
      Object.entries(strategy).forEach(([key, value]) => {
        items.push({
          question: formatAnalysisLabel(key),
          answer: isScalarValue(value)
            ? formatScalarDisplay(value)
            : collectTextItems(value).join(" "),
        });
      });
    }

    return items
      .map((item) => ({
        question: sanitizeDisplayText(item.question, { maxLength: 400 }),
        answer: sanitizeDisplayText(item.answer, { maxLength: 2500 }),
      }))
      .filter((item) => item.question && item.answer);
  };

  const renderFaq = (analysis, listingId) => {
    const items = normalizeFaqItems(analysis);
    const body =
      items.length > 0
        ? renderAccordionItems(items, listingId, "faq")
        : '<p class="muted-label empty-state">Česta pitanja nisu dostupna za ovaj oglas.</p>';

    return renderSectionCard("Česta pitanja", body, "faq-module");
  };

  const renderNegotiationSection = (analysis, listingId) => {
    const items = normalizeNegotiationItems(analysis);
    const body =
      items.length > 0
        ? renderAccordionItems(items, listingId, "nego")
        : '<p class="muted-label empty-state">Strategija pregovaranja nije dostupna.</p>';

    return renderSectionCard("Strategija pregovaranja", body, "negotiation-module");
  };

  const renderAnalysisFeed = (listing, analysis) => {
    const excludedKeys = new Set([
      "contact",
      "seller_contact",
      "phone",
      "phone_number",
      "agency",
      "agency_name",
      "owner_name",
      "financials",
      "valuation",
      "cost_breakdown",
      "costs",
      "deal_score",
      "insights",
      "highlights",
      "red_flags",
      "risks",
      "recommended_checks",
      "legal_checks",
      "technical_checks",
      "legal_technical_checks",
      "negotiation_strategy",
      "negotiation_strategy_lines",
      "target_discount_pct",
      "target_discount_percentage",
      "leverage_points",
      "dynamic_faq",
      "faq",
      "dynamic_quick_prompts",
    ]);
    const overviewEntries = Object.entries(analysis).filter(([key]) => !excludedKeys.has(key));

    return `
      ${renderPriceBanner(listing, analysis)}
      ${renderContactCard(listing, analysis)}
      ${renderFinancialsSection(analysis)}
      ${renderDealScore(analysis)}
      ${overviewEntries.map(renderAnalysisModule).join("")}
      ${renderAlertCards(analysis)}
      ${renderRecommendedChecks(analysis)}
      ${renderNegotiationSection(analysis, listing.id)}
      ${renderFaq(analysis, listing.id)}
    `;
  };

  const renderAnalysisSkeleton = (listing) => `
    <div
      class="accordion-panel skeleton-panel"
      id="panel-${listing.id}"
      role="region"
      aria-labelledby="trigger-${listing.id}"
      aria-busy="true"
    >
      <div class="analysis-grid skeleton-grid">
        <section class="analysis-module skeleton-status-card" aria-live="polite">
          <p class="skeleton-status-text">
            <span class="skeleton-pulse-dot" aria-hidden="true"></span>
            AI analizira tržišne podatke...
          </p>
        </section>

        <section class="analysis-module skeleton-card skeleton-financials" aria-label="Učitavanje finansijskog pregleda">
          <div class="skeleton-box skeleton-price-box"></div>
          <div class="skeleton-badge-row">
            <span class="skeleton-box skeleton-badge"></span>
            <span class="skeleton-box skeleton-badge"></span>
          </div>
        </section>

        <section class="analysis-module skeleton-card skeleton-score" aria-label="Učitavanje AI ocene ponude">
          <div class="skeleton-box skeleton-score-bar"></div>
        </section>

        <section class="analysis-module skeleton-card skeleton-insights" aria-label="Učitavanje rizika i prednosti">
          <div class="skeleton-box skeleton-line skeleton-line-100"></div>
          <div class="skeleton-box skeleton-line skeleton-line-80"></div>
          <div class="skeleton-box skeleton-line skeleton-line-60"></div>
        </section>

        <section class="analysis-module skeleton-card skeleton-prompts" aria-label="Učitavanje brzih upita">
          <div class="skeleton-chip-row">
            <span class="skeleton-box skeleton-chip"></span>
            <span class="skeleton-box skeleton-chip"></span>
            <span class="skeleton-box skeleton-chip"></span>
          </div>
        </section>
      </div>
    </div>
  `;

  const renderListingDetails = (listing) => {
    const { analysis } = listing;

    if (!analysis) {
      return "";
    }

    return `
      <div class="accordion-panel analysis-ready" id="panel-${listing.id}" role="region" aria-labelledby="trigger-${listing.id}">
        <div class="analysis-grid analysis-feed">
          ${renderAnalysisFeed(listing, analysis)}
          <section class="analysis-module action-module" aria-label="Akcije">
            <button class="save-dashboard-button" type="button" data-listing-id="${listing.id}">Sačuvaj na Dashboard</button>
            <p class="action-feedback" id="feedback-${listing.id}" aria-live="polite"></p>
          </section>
        </div>
      </div>
    `;
  };

  const renderListing = (listing) => {
    const isOpen = listing.unlocked && listing.id === openListingId;
    const cardStateClass = listing.unlocked ? "is-unlocked" : "is-locked";
    const isAnalyzing = analyzingListingId === listing.id;
    const lockedHelpText = listing.analysisError || "Analiza ovog oglasa još nije pokrenuta.";

    if (isAnalyzing) {
      return `
        <article class="listing-card is-unlocked is-open is-analysis-loading" data-listing-id="${listing.id}">
          <button
            id="trigger-${listing.id}"
            class="listing-trigger skeleton-trigger"
            type="button"
            data-listing-id="${listing.id}"
            aria-expanded="true"
            aria-controls="panel-${listing.id}"
            aria-busy="true"
            disabled
          >
            <span class="listing-main">
              <span class="listing-title">${escapeHtml(listing.title)}</span>
              <span class="listing-meta">${escapeHtml(listing.location)}</span>
            </span>
            <span class="listing-side">
              <strong>${escapeHtml(listing.price)}</strong>
              <span class="badge badge-warning">Analiza u toku</span>
            </span>
          </button>

          ${renderAnalysisSkeleton(listing)}
        </article>
      `;
    }

    if (!listing.unlocked) {
      return `
        <article class="listing-card ${cardStateClass}" data-listing-id="${listing.id}">
          <div class="listing-trigger locked-trigger" aria-describedby="locked-help-${listing.id}">
            <span class="listing-main">
              <span class="listing-title">${escapeHtml(listing.title)}</span>
              <span class="listing-meta">${escapeHtml(listing.location)}</span>
            </span>
            <span class="listing-side">
              <strong>${escapeHtml(listing.price)}</strong>
              <button
                class="unlock-button unlock-inline ${isAnalyzing ? "is-loading" : ""}"
                type="button"
                data-listing-id="${listing.id}"
                ${isAnalyzing ? "disabled" : ""}
                aria-busy="${String(isAnalyzing)}"
              >
                <span aria-hidden="true">${isAnalyzing ? "⏳" : "🔒"}</span>
                <span>${isAnalyzing ? "Analiziram..." : "Otključaj analizu (-1 kredit)"}</span>
              </button>
            </span>
          </div>
          <p id="locked-help-${listing.id}" class="locked-help ${
            listing.analysisError ? "unlock-error" : ""
          }">${escapeHtml(lockedHelpText)}</p>
        </article>
      `;
    }

    return `
      <article class="listing-card ${cardStateClass} ${isOpen ? "is-open" : ""}" data-listing-id="${listing.id}">
        <button
          id="trigger-${listing.id}"
          class="listing-trigger"
          type="button"
          data-listing-id="${listing.id}"
          aria-expanded="${String(isOpen)}"
          aria-controls="panel-${listing.id}"
        >
          <span class="listing-main">
            <span class="listing-title">${escapeHtml(listing.title)}</span>
            <span class="listing-meta">${escapeHtml(listing.location)}</span>
          </span>
          <span class="listing-side">
            <strong>${escapeHtml(listing.price)}</strong>
            <span class="badge badge-success">Analizirano</span>
          </span>
          <span class="accordion-indicator" aria-hidden="true">
            <svg class="accordion-icon accordion-icon-arrow" viewBox="0 0 24 24" focusable="false">
              <path d="m6 9 6 6 6-6"></path>
            </svg>
            <svg class="accordion-icon accordion-icon-close" viewBox="0 0 24 24" focusable="false">
              <path d="M6 6l12 12M18 6 6 18"></path>
            </svg>
          </span>
        </button>

        ${isOpen ? renderListingDetails(listing) : ""}
      </article>
    `;
  };

  const renderListings = () => {
    updateListingsSummary();

    if (listings.length === 0) {
      purgeListingDom();
      return;
    }

    accordion.innerHTML = listings.map(renderListing).join("");
  };

  const collectActiveTabPageContent = async () => {
    if (typeof chrome === "undefined" || !chrome.scripting?.executeScript) {
      return { html: "", rawText: "" };
    }

    const tab = await getActiveTab();

    if (!canInspectTab(tab)) {
      return { html: "", rawText: "" };
    }

    try {
      const [injectionResult] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const NON_CONTENT_SELECTOR =
            "script, style, iframe, noscript, template, link[rel='stylesheet']";

          const sanitizeRoot = (root) => {
            if (!root) {
              return null;
            }

            const clone = root.cloneNode(true);
            clone.querySelectorAll(NON_CONTENT_SELECTOR).forEach((node) => node.remove());

            const walker = document.createTreeWalker(clone, NodeFilter.SHOW_COMMENT);
            const comments = [];

            while (walker.nextNode()) {
              comments.push(walker.currentNode);
            }

            comments.forEach((comment) => comment.remove());
            return clone;
          };

          const cleanDocument = sanitizeRoot(document.documentElement);
          const html = cleanDocument?.outerHTML?.slice(0, 120000) || "";
          // Live innerText already skips script/style; keep it for readable page copy.
          const rawText = (document.body?.innerText || "")
            .replace(/\s+/g, " ")
            .trim()
            .slice(0, 40000);

          return { html, rawText };
        },
      });

      return {
        html: injectionResult?.result?.html || "",
        rawText: String(injectionResult?.result?.rawText || "")
          .replace(/<script[\s\S]*?<\/script>/gi, " ")
          .replace(/<style[\s\S]*?<\/style>/gi, " ")
          .replace(/\s+/g, " ")
          .trim()
          .slice(0, 40000),
      };
    } catch (error) {
      console.error("Failed to collect page content for analysis.", error);
      return { html: "", rawText: "" };
    }
  };

  const buildAnalysisRequestListing = async (listing) => {
    const detectedListing = listing?.detection?.listing;
    const features =
      listing?.detection?.detection?.signals?.property_context_matches ?? [];
    const sqm = detectedListing?.surface_area?.sqm ?? null;
    const description = sanitizeDisplayText(detectedListing?.description ?? "", {
      maxLength: 8000,
    });
    const pageContent = await collectActiveTabPageContent();
    const rawText =
      pageContent.rawText ||
      [detectedListing?.title, description, detectedListing?.location]
        .map((part) => sanitizeDisplayText(part, { maxLength: 8000 }))
        .filter(Boolean)
        .join("\n\n");

    return {
      title: sanitizeDisplayText(detectedListing?.title ?? "", { maxLength: 500 }),
      price: detectedListing?.price?.value ?? detectedListing?.price?.raw ?? null,
      location: sanitizeDisplayText(detectedListing?.location ?? "", { maxLength: 500 }),
      sqm,
      m2: sqm,
      description,
      html: pageContent.html || "",
      rawText,
      features: Array.isArray(features)
        ? features
            .map((feature) => sanitizeDisplayText(feature, { maxLength: 200 }))
            .filter(Boolean)
        : [],
      portal_url: detectedListing?.listing_url ?? "",
    };
  };

  const getAnalysisAccessToken = async () => {
    const storedSession = await getStoredSessionSnapshot();
    return parseStoredSession(storedSession)?.accessToken ?? lastAppliedAccessToken;
  };

  const consumeCredit = async () => {
    if (!currentUser || !currentProfile) {
      showToast("Prijavite se na sajtu da biste koristili analizu.");
      return null;
    }

    const previousCredits = credits;
    const nextCredits = previousCredits - CREDIT_COST_PER_UNLOCK;

    if (previousCredits <= 0 || nextCredits < 0) {
      showToast("Nemate dovoljno kredita.");
      return null;
    }

    const { data, error } = await supabaseClient
      .from("profiles")
      .update({ credits_remaining: nextCredits })
      .eq("id", currentUser.id)
      .eq("credits_remaining", previousCredits)
      .select("*")
      .maybeSingle();

    if (error) {
      throw error;
    }

    if (!data) {
      await fetchAndRenderProfile(currentUser);
      showToast("Krediti su promenjeni. Pokušajte ponovo.");
      return null;
    }

    currentProfile = data;
    renderAuthenticatedProfile(currentProfile, currentUser);
    return data;
  };

  const fetchRealAnalysis = async (listingPayload, accessToken) => {
    const headers = {
      "Content-Type": "application/json",
    };

    if (accessToken) {
      headers.Authorization = `Bearer ${accessToken}`;
    }

    console.log("REAL API REQUEST:", ANALYZE_API_URL, listingPayload);

    let response;

    try {
      response = await fetch(ANALYZE_API_URL, {
        method: "POST",
        headers,
        body: JSON.stringify(listingPayload),
      });
    } catch (error) {
      console.error("Analyze network request failed.", error);
      throw new Error(ANALYZE_API_ERROR_MESSAGE);
    }

    let data = null;

    try {
      data = await response.json();
    } catch {
      data = null;
    }

    console.log("REAL API RESPONSE:", data);

    if (!response.ok) {
      throw new Error(ANALYZE_API_ERROR_MESSAGE);
    }

    const analysis = data?.analysis ?? data?.data?.analysis ?? data?.data ?? data;

    if (!analysis || typeof analysis !== "object" || Array.isArray(analysis)) {
      throw new Error(ANALYZE_API_ERROR_MESSAGE);
    }

    return analysis;
  };

  const unlockListing = async (id) => {
    const listing = getListingById(id);

    if (!listing || listing.unlocked || analyzingListingId) {
      return;
    }

    if (
      isNoListingsFoundResult(currentDetectionResult) ||
      !listing.isDetectionValid ||
      !currentDetectionResult?.is_valid_listing
    ) {
      showNoListingWarningState();
      return;
    }

    if (!currentUser || !currentProfile) {
      showToast("Prijavite se na sajtu da biste koristili analizu.");
      return;
    }

    if (credits <= 0) {
      showToast("Nemate dovoljno kredita.");
      return;
    }

    analyzingListingId = id;
    listing.analysisError = "";
    renderListings();

    try {
      const accessToken = await getAnalysisAccessToken();
      const analysisPayload = await buildAnalysisRequestListing(listing);
      const analysis = await fetchRealAnalysis(analysisPayload, accessToken);

      if (
        isNoListingsFoundResult(currentDetectionResult) ||
        !getListingById(id)?.isDetectionValid
      ) {
        showNoListingWarningState();
        return;
      }

      const updatedProfile = await consumeCredit();

      if (!updatedProfile) {
        listing.analysisError = "Krediti nisu skinuti. Pokušajte ponovo.";
        return;
      }

      listing.analysis = analysis;
      listing.unlocked = true;
      openListingId = id;
    } catch (error) {
      console.error("Failed to unlock listing analysis.", error);
      listing.analysis = undefined;
      listing.unlocked = false;
      listing.analysisError = ANALYZE_API_ERROR_MESSAGE;
    } finally {
      analyzingListingId = null;
      renderListings();
    }
  };

  const toggleListing = (id) => {
    const listing = getListingById(id);

    if (!listing?.unlocked) {
      return;
    }

    openListingId = openListingId === id ? null : id;
    renderListings();
  };

  const setActionFeedback = (id, text) => {
    const feedback = document.querySelector(`#feedback-${id}`);

    if (feedback) {
      feedback.textContent = text;
    }
  };

  accordion.addEventListener("click", (event) => {
    const trigger = event.target.closest(".listing-trigger");
    const unlockButton = event.target.closest(".unlock-button");
    const saveButton = event.target.closest(".save-dashboard-button");
    const faqQuestion = event.target.closest(".faq-question");

    if (unlockButton) {
      unlockListing(unlockButton.dataset.listingId);
      return;
    }

    if (faqQuestion) {
      const faqItem = faqQuestion.closest(".faq-item");
      const answer = faqItem?.querySelector(".faq-answer");
      const wasOpen = faqItem?.classList.contains("is-open") ?? false;
      const faqList = faqQuestion.closest(".faq-list");

      faqList?.querySelectorAll(".faq-item.is-open").forEach((item) => {
        item.classList.remove("is-open");
        item.querySelector(".faq-question")?.setAttribute("aria-expanded", "false");
        item.querySelector(".faq-answer")?.setAttribute("hidden", "");
      });

      if (!wasOpen && faqItem) {
        faqItem.classList.add("is-open");
        faqQuestion.setAttribute("aria-expanded", "true");
        answer?.removeAttribute("hidden");
      }
      return;
    }

    if (trigger) {
      toggleListing(trigger.dataset.listingId);
      return;
    }

    if (saveButton) {
      setActionFeedback(saveButton.dataset.listingId, "Oglas je sačuvan na Dashboard.");
    }
  });

  const runListingDetection = async ({ showLoading = true } = {}) => {
    const requestId = currentScanRequestId + 1;
    currentScanRequestId = requestId;
    clearScanTimer();
    resetScanResults();
    setActivePanel("scan");
    setScanNotice("");

    if (showLoading) {
      setScannerLoading(true);
    }

    try {
      const detectionResult = await inspectActiveTabListing();

      if (requestId !== currentScanRequestId) {
        return;
      }

      if (isNoListingsFoundResult(detectionResult) || !isValidDetectionPayload(detectionResult)) {
        showNoListingWarningState();
        return;
      }

      currentDetectionResult = detectionResult;
      listings = [mapDetectionToListing(detectionResult)];
      purgeListingDom();
      renderListings();
      setPartialDataWarning(detectionResult.has_partial_data);
      setScanNotice("");
      setActivePanel("results");
    } catch (error) {
      console.error("Listing detection failed.", error);
      if (requestId === currentScanRequestId) {
        showNoListingWarningState();
      }
    } finally {
      if (requestId === currentScanRequestId) {
        analyzingListingId = null;
        setScannerLoading(false);
      }
    }
  };

  scanButton.addEventListener("click", () => {
    void runListingDetection();
  });

  retryScanButton.addEventListener("click", () => {
    void runListingDetection();
  });

  devToggle?.addEventListener("click", () => {
    currentScanRequestId += 1;
    clearScanTimer();
    resetScanResults();
    setScanNotice("");
    setScannerLoading(false);
    setActivePanel("scan");
  });

  const handleStorageChange = (changes, areaName) => {
    if (areaName !== "local" || !(EXTENSION_SESSION_STORAGE_KEY in changes)) {
      return;
    }

    const storedSession = changes[EXTENSION_SESSION_STORAGE_KEY].newValue ?? null;

    if (storedSession === lastStoredSessionValue) {
      return;
    }

    window.clearTimeout(authSyncTimer);
    authSyncTimer = window.setTimeout(() => {
      void applyStoredSession(storedSession, { clearOnMissing: true });
    }, 150);
  };

  const handleAuthStateChange = (_event, session) => {
    if (!session?.user?.id || session.user.id === currentUser?.id) {
      if (!session) {
        void applyStoredSession(null, { clearOnMissing: true });
      }
      return;
    }

    void applyStoredSession(
      JSON.stringify({
        currentSession: session,
        expiresAt: session.expires_at ?? null,
      }),
      { clearOnMissing: true },
    );
  };

  const authSubscription = supabaseClient?.auth?.onAuthStateChange
    ? supabaseClient.auth.onAuthStateChange(handleAuthStateChange).data.subscription
    : null;

  chrome.storage?.onChanged?.addListener(handleStorageChange);

  window.addEventListener("unload", () => {
    chrome.storage?.onChanged?.removeListener(handleStorageChange);
    authSubscription?.unsubscribe();
    unsubscribeFromProfileChanges();
    clearScanTimer();
    window.clearTimeout(authSyncTimer);
    window.clearTimeout(toastTimer);
  });

  renderListings();
  setResultsVisible(false);
  setScanNotice("");
  void initializeAuthState();
});
