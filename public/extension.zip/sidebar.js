const DEFAULT_CREDITS_LIMIT = 5;
const CREDIT_COST_PER_UNLOCK = 1;
const PROFILE_CACHE_STORAGE_PREFIX = "brei:profile:";
const LISTING_DETECTOR_FILE = "content/listingDetector.js";
const NO_LISTING_HEADING = "Nije detektovan oglas za analizu";
const NO_LISTING_MESSAGE =
  "Molimo vas da otvorite stranicu sa pojedinačnim oglasom na podržanim portalima (npr. Halo Oglasi) i osvežite stranicu.";
const ANALYZE_API_ERROR_MESSAGE =
  "Greška pri povezivanju sa AI serverom. Pokušajte ponovo.";
const PARTIAL_DATA_MESSAGE =
  "Upozorenje: Ovaj oglas sadrži ograničen obim informacija na samoj stranici. AI analiza je izvršena na osnovu raspoloživih podataka.";
const ANALYZE_API_URL = "https://real-estate-lac-ten.vercel.app/api/scan/analyze";

document.addEventListener("DOMContentLoaded", () => {
  const scanState = document.querySelector("#scan-state");
  const noListingState = document.querySelector("#no-listing-state");
  const resultsState = document.querySelector("#results-state");
  const scanButton = document.querySelector("#scan-button");
  const retryScanButton = document.querySelector("#retry-scan-button");
  const scanNotice = document.querySelector("#scan-notice");
  const listingsSummaryTitle = document.querySelector("#listings-summary-title");
  const summaryBadge = document.querySelector("#summary-badge");
  const partialDataWarning = document.querySelector("#partial-data-warning");
  const accordion = document.querySelector("#listings-accordion");
  const profileCard = document.querySelector("#profile-card");
  const profileAvatar = document.querySelector("#profile-avatar");
  const profileLabel = document.querySelector("#profile-label");
  const profileSubtitle = document.querySelector("#profile-subtitle");
  const profileEmail = document.querySelector("#profile-email");
  const profileAction = document.querySelector("#profile-action");
  const creditsLabel = document.querySelector("#credits-label");
  const creditsPercent = document.querySelector("#credits-percent");
  const creditsProgress = document.querySelector("#credits-progress");
  const creditsFill = document.querySelector("#credits-fill");
  const dashboardLink = document.querySelector("#dashboard-link");
  const toast = document.querySelector("#toast");
  const devToggle = document.querySelector(".dev-state-toggle");

  if (
    !scanState ||
    !noListingState ||
    !resultsState ||
    !scanButton ||
    !retryScanButton ||
    !scanNotice ||
    !listingsSummaryTitle ||
    !summaryBadge ||
    !partialDataWarning ||
    !accordion ||
    !profileCard ||
    !profileAvatar ||
    !profileLabel ||
    !profileSubtitle ||
    !profileEmail ||
    !profileAction ||
    !creditsLabel ||
    !creditsPercent ||
    !creditsProgress ||
    !creditsFill ||
    !dashboardLink ||
    !toast
  ) {
    return;
  }

  function purgeListingDom() {
    accordion.replaceChildren();
    resultsState.querySelectorAll(".listing-card").forEach((card) => {
      card.remove();
    });
  }

  purgeListingDom();
  resultsState.classList.add("is-hidden");
  resultsState.setAttribute("aria-hidden", "true");
  noListingState.classList.add("is-hidden");
  noListingState.setAttribute("aria-hidden", "true");

  const {
    EXTENSION_SESSION_STORAGE_KEY,
    SUPABASE_WEBSITE_STORAGE_KEY,
    WEBSITE_DASHBOARD_URL,
    WEBSITE_LOGIN_URL,
    WEBSITE_ORIGIN,
  } = window.breiConfig ?? {};

  const supabaseClient = window.breiSupabase;

  let currentUser = null;
  let currentProfile = null;
  let profileChannel = null;
  let profileChannelUserId = null;
  let lastStoredSessionValue;
  let lastAppliedAccessToken = null;
  let profileRequestId = 0;
  let authSyncTimer = null;
  let credits = 0;
  let creditsLimit = DEFAULT_CREDITS_LIMIT;
  let openListingId = null;
  let listings = [];
  let analyzingListingId = null;
  let scanTimer = null;
  let currentScanRequestId = 0;
  let currentDetectionResult = null;
  let toastTimer = null;

  const escapeHtml = (value) =>
    String(value ?? "").replace(/[&<>"']/g, (character) => {
      const entities = {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;",
      };

      return entities[character];
    });

  const formatNumber = (value) =>
    new Intl.NumberFormat("sr-RS", {
      maximumFractionDigits: 0,
    }).format(value);

  const clamp = (value, min, max) => Math.min(Math.max(value, min), max);

  const getProfileCacheKey = (userId) => `${PROFILE_CACHE_STORAGE_PREFIX}${userId}`;

  const getStoredSessionSnapshot = async () => {
    if (
      !EXTENSION_SESSION_STORAGE_KEY ||
      typeof chrome === "undefined" ||
      !chrome.storage?.local
    ) {
      return null;
    }

    const result = await chrome.storage.local.get(EXTENSION_SESSION_STORAGE_KEY);
    return result[EXTENSION_SESSION_STORAGE_KEY] ?? null;
  };

  const importSessionFromActiveWebsiteTab = async () => {
    if (
      !EXTENSION_SESSION_STORAGE_KEY ||
      !SUPABASE_WEBSITE_STORAGE_KEY ||
      !WEBSITE_ORIGIN ||
      typeof chrome === "undefined" ||
      !chrome.tabs?.query ||
      !chrome.scripting?.executeScript ||
      !chrome.storage?.local
    ) {
      return null;
    }

    try {
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const websiteTabs = await chrome.tabs.query({ url: `${WEBSITE_ORIGIN}/*` });
      const candidateTabs = [
        activeTab,
        ...websiteTabs.filter((tab) => tab.id !== activeTab?.id),
      ].filter(
        (tab) =>
          tab?.id &&
          (tab.url === WEBSITE_ORIGIN || tab.url?.startsWith(`${WEBSITE_ORIGIN}/`)),
      );

      for (const tab of candidateTabs) {
        const [injectionResult] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          args: [SUPABASE_WEBSITE_STORAGE_KEY],
          func: (storageKey) => {
          const base64CookiePrefix = "base64-";

          const decodeBase64Url = (value) => {
            const base64 = value.replace(/-/g, "+").replace(/_/g, "/");
            const padded = base64.padEnd(
              base64.length + ((4 - (base64.length % 4)) % 4),
              "=",
            );
            return decodeURIComponent(
              Array.from(atob(padded), (character) =>
                `%${character.charCodeAt(0).toString(16).padStart(2, "0")}`,
              ).join(""),
            );
          };

          const normalizeSessionValue = (value) => {
            if (!value) {
              return null;
            }

            if (value.startsWith(base64CookiePrefix)) {
              return decodeBase64Url(value.slice(base64CookiePrefix.length));
            }

            return value;
          };

          const readChunkedCookie = (cookies, key) => {
            if (cookies[key]) {
              return cookies[key];
            }

            const chunks = [];

            for (let index = 0; index < 10; index += 1) {
              const chunk = cookies[`${key}.${index}`];

              if (!chunk) {
                break;
              }

              chunks.push(chunk);
            }

            return chunks.length > 0 ? chunks.join("") : null;
          };

          const readCookies = () =>
            document.cookie
              .split(";")
              .map((cookie) => cookie.trim())
              .filter(Boolean)
              .reduce((cookies, cookie) => {
                const separatorIndex = cookie.indexOf("=");

                if (separatorIndex === -1) {
                  return cookies;
                }

                cookies[decodeURIComponent(cookie.slice(0, separatorIndex))] =
                  decodeURIComponent(cookie.slice(separatorIndex + 1));
                return cookies;
              }, {});

          const localStorageSession = window.localStorage.getItem(storageKey);

          if (localStorageSession) {
            return localStorageSession;
          }

          const cookies = readCookies();
          return normalizeSessionValue(readChunkedCookie(cookies, storageKey));
          },
        });

        const sessionValue =
          typeof injectionResult?.result === "string" ? injectionResult.result : null;

        if (sessionValue) {
          await chrome.storage.local.set({ [EXTENSION_SESSION_STORAGE_KEY]: sessionValue });
          return sessionValue;
        }
      }

      if (candidateTabs.length > 0) {
        await chrome.storage.local.remove(EXTENSION_SESSION_STORAGE_KEY);
      }

      return null;
    } catch (error) {
      console.error("[Extension Auth] Could not import session from website tab.", error);
      return null;
    }
  };

  const getCachedProfile = async (userId) => {
    if (!userId || typeof chrome === "undefined" || !chrome.storage?.local) {
      return null;
    }

    try {
      const cacheKey = getProfileCacheKey(userId);
      const result = await chrome.storage.local.get(cacheKey);
      return result[cacheKey] ?? null;
    } catch (error) {
      console.error("[Extension Auth] Could not read cached profile.", error);
      return null;
    }
  };

  const setCachedProfile = async (userId, profile) => {
    if (!userId || !profile || typeof chrome === "undefined" || !chrome.storage?.local) {
      return;
    }

    try {
      await chrome.storage.local.set({ [getProfileCacheKey(userId)]: profile });
    } catch (error) {
      console.error("[Extension Auth] Could not cache profile.", error);
    }
  };

  const parseStoredSession = (storedSession) => {
    if (!storedSession) {
      return null;
    }

    try {
      const parsedSession =
        typeof storedSession === "string" ? JSON.parse(storedSession) : storedSession;
      const session = parsedSession.currentSession || parsedSession.session || parsedSession;

      if (session?.access_token && session?.refresh_token && session?.user) {
        return {
          session,
          user: session.user,
          accessToken: session.access_token,
          refreshToken: session.refresh_token,
        };
      }
    } catch (error) {
      console.error("[Extension Auth] Stored session could not be parsed:", error);
    }

    return null;
  };

  const restoreSessionIfChanged = async (auth) => {
    if (!auth?.accessToken || !auth?.refreshToken || !supabaseClient?.auth?.setSession) {
      return;
    }

    if (auth.accessToken === lastAppliedAccessToken) {
      return;
    }

    const { error } = await supabaseClient.auth.setSession({
      access_token: auth.accessToken,
      refresh_token: auth.refreshToken,
    });

    if (error) {
      throw error;
    }

    lastAppliedAccessToken = auth.accessToken;
  };

  const getNumberValue = (...values) => {
    const value = values.find((candidate) => Number.isFinite(Number(candidate)));
    return value === undefined ? 0 : Number(value);
  };

  const getDisplayName = (profile, user) => {
    const fullName = (profile?.fullname || profile?.full_name || profile?.name)?.trim();
    return fullName || user?.email || "Korisnik";
  };

  const getInitials = (value) => {
    const normalized = String(value ?? "")
      .replace(/@.*/, "")
      .trim();

    if (!normalized) {
      return "BR";
    }

    const parts = normalized.split(/\s+/).filter(Boolean);

    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
    }

    return normalized.slice(0, 2).toUpperCase();
  };

  const getTierLabel = (profile) => {
    const status = profile?.subscription_status ?? "trial";
    const labels = {
      active: "Active subscriber",
      canceled: "Subscription canceled",
      expired: "Subscription expired",
      trial: "Beta Access User",
    };

    return labels[status] ?? status.replace(/_/g, " ");
  };

  const setProfileStateClass = (state) => {
    profileCard.classList.toggle("is-loading", state === "loading");
    profileCard.classList.toggle("is-unauthenticated", state === "unauthenticated");
    profileCard.classList.toggle("is-error", state === "error");
  };

  const showToast = (message) => {
    window.clearTimeout(toastTimer);
    toast.textContent = message;
    toast.classList.add("is-visible");
    toast.setAttribute("aria-hidden", "false");

    toastTimer = window.setTimeout(() => {
      toast.classList.remove("is-visible");
      toast.setAttribute("aria-hidden", "true");
    }, 3200);
  };

  const updateCredits = () => {
    const safeLimit = Math.max(creditsLimit, 1);
    const percentage = clamp(Math.round((credits / safeLimit) * 100), 0, 100);

    creditsLabel.textContent = `Credits: ${credits} / ${creditsLimit}`;
    creditsPercent.textContent = `${percentage}%`;
    creditsProgress.setAttribute("aria-label", `Krediti: ${credits} od ${creditsLimit}`);
    creditsFill.style.width = `${percentage}%`;
  };

  const renderUnauthenticatedProfile = () => {
    currentUser = null;
    currentProfile = null;
    credits = 0;
    creditsLimit = DEFAULT_CREDITS_LIMIT;
    setProfileStateClass("unauthenticated");
    profileAvatar.textContent = "BR";
    profileLabel.textContent = "Niste prijavljeni";
    profileSubtitle.textContent = "Kliknite Prijava da povežete nalog.";
    profileEmail.textContent = "";
    profileAction.textContent = "Prijava";
    profileAction.href = WEBSITE_LOGIN_URL || "#";
    dashboardLink.href = WEBSITE_DASHBOARD_URL || "#";
    updateCredits();
  };

  const renderAuthenticatedProfile = (profile, user) => {
    const displayName = getDisplayName(profile, user);
    credits = clamp(
      Math.floor(getNumberValue(profile?.credits_remaining, profile?.credits)),
      0,
      Number.MAX_SAFE_INTEGER,
    );
    creditsLimit = Math.max(
      Math.floor(getNumberValue(profile?.credits_limit, profile?.credits_total, DEFAULT_CREDITS_LIMIT)),
      1,
    );

    setProfileStateClass("authenticated");
    profileAvatar.textContent = getInitials(displayName);
    profileLabel.textContent = displayName;
    profileSubtitle.textContent = getTierLabel(profile);
    profileEmail.textContent = user?.email || profile?.email || "";
    profileAction.textContent = "Upgrade";
    profileAction.href = WEBSITE_DASHBOARD_URL || "#";
    dashboardLink.href = WEBSITE_DASHBOARD_URL || "#";
    updateCredits();
  };

  const unsubscribeFromProfileChanges = () => {
    if (!profileChannel) {
      profileChannelUserId = null;
      return;
    }

    supabaseClient.removeChannel(profileChannel);
    profileChannel = null;
    profileChannelUserId = null;
  };

  const subscribeToProfileChanges = (userId) => {
    if (!userId || profileChannelUserId === userId) {
      return;
    }

    unsubscribeFromProfileChanges();
    profileChannelUserId = userId;

    profileChannel = supabaseClient
      .channel(`profile-credit-${userId}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          filter: `id=eq.${userId}`,
          schema: "public",
          table: "profiles",
        },
        (payload) => {
          if (currentUser?.id !== userId || payload.new?.id !== userId) {
            console.warn("[Extension Auth] Ignored profile update for inactive user.", {
              activeUserId: currentUser?.id ?? null,
              subscribedUserId: userId,
              profileUserId: payload.new?.id ?? null,
            });
            return;
          }

          currentProfile = payload.new;
          void setCachedProfile(userId, currentProfile);
          renderAuthenticatedProfile(currentProfile, currentUser);
        },
      )
      .subscribe((status, error) => {
        if (error) {
          console.error("Supabase profile realtime subscription error.", error);
        }

        if (status === "CHANNEL_ERROR") {
          console.error("Supabase profile realtime channel failed.");
        }
      });
  };

  const fetchAndRenderProfile = async (user, requestId = ++profileRequestId) => {
    if (!user?.id || !supabaseClient?.from) {
      return null;
    }

    try {
      const { data, error } = await supabaseClient
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .maybeSingle();

      if (error) {
        throw error;
      }

      if (requestId !== profileRequestId || currentUser?.id !== user.id) {
        return null;
      }

      if (!data) {
        console.warn("[Extension Auth] No profile row found for active user.", user.id);
        return null;
      }

      currentProfile = data;
      await setCachedProfile(user.id, data);
      renderAuthenticatedProfile(currentProfile, currentUser);
      subscribeToProfileChanges(user.id);
      return data;
    } catch (error) {
      console.error("[Extension Profile Fetch Error:]", error);
      if (currentUser?.id === user.id) {
        renderAuthenticatedProfile(currentProfile, currentUser);
      }
      return null;
    }
  };

  const applyStoredSession = async (storedSession, { clearOnMissing = false } = {}) => {
    const auth = parseStoredSession(storedSession);

    if (!auth?.user?.id) {
      lastStoredSessionValue = storedSession ?? null;
      lastAppliedAccessToken = null;
      profileRequestId += 1;
      unsubscribeFromProfileChanges();

      if (clearOnMissing || !currentUser) {
        renderUnauthenticatedProfile();
      }

      return null;
    }

    lastStoredSessionValue = storedSession;
    const cachedProfile = await getCachedProfile(auth.user.id);
    const immediateProfile =
      cachedProfile ?? (currentUser?.id === auth.user.id ? currentProfile : null);

    currentUser = auth.user;
    currentProfile = immediateProfile;
    renderAuthenticatedProfile(currentProfile, currentUser);

    try {
      await restoreSessionIfChanged(auth);
    } catch (error) {
      console.error("[Extension Auth] Stored session restore failed:", error);
      return currentProfile;
    }

    return fetchAndRenderProfile(currentUser);
  };

  const initializeAuthState = async () => {
    try {
      await importSessionFromActiveWebsiteTab();
      const storedSession = await getStoredSessionSnapshot();

      if (storedSession) {
        await applyStoredSession(storedSession, { clearOnMissing: true });
        return;
      }

      const { data, error } = supabaseClient?.auth?.getSession
        ? await supabaseClient.auth.getSession()
        : { data: null, error: null };

      if (error) {
        throw error;
      }

      if (data?.session) {
        await applyStoredSession(
          JSON.stringify({
            currentSession: data.session,
            expiresAt: data.session.expires_at ?? null,
          }),
          { clearOnMissing: true },
        );
        return;
      }

      renderUnauthenticatedProfile();
    } catch (error) {
      console.error("[Extension Auth] Initial auth state failed:", error);
      if (currentUser) {
        renderAuthenticatedProfile(currentProfile, currentUser);
      } else {
        renderUnauthenticatedProfile();
      }
    }
  };

  const setScannerLoading = (isLoading) => {
    scanButton.classList.toggle("is-loading", isLoading);
    scanButton.setAttribute("aria-busy", String(isLoading));
    retryScanButton.classList.toggle("is-loading", isLoading);
    retryScanButton.setAttribute("aria-busy", String(isLoading));

    if (isLoading) {
      scanButton.disabled = true;
      retryScanButton.disabled = true;
      return;
    }

    const isNoListingPanel = !noListingState.classList.contains("is-hidden");
    scanButton.disabled = isNoListingPanel;
    retryScanButton.disabled = false;
  };

  const clearScanTimer = () => {
    if (scanTimer) {
      window.clearTimeout(scanTimer);
      scanTimer = null;
    }
  };

  const setScanNotice = (message = "") => {
    scanNotice.textContent = message;
    scanNotice.classList.toggle("is-hidden", !message);
    scanNotice.setAttribute("aria-hidden", String(!message));
  };

  const setPartialDataWarning = (isVisible) => {
    partialDataWarning.textContent = isVisible ? PARTIAL_DATA_MESSAGE : "";
    partialDataWarning.classList.toggle("is-hidden", !isVisible);
    partialDataWarning.setAttribute("aria-hidden", String(!isVisible));
  };

  const resetScanResults = () => {
    currentDetectionResult = null;
    listings = [];
    openListingId = null;
    analyzingListingId = null;
    setPartialDataWarning(false);
    purgeListingDom();
    renderListings();
  };

  const setActivePanel = (panel) => {
    const showScan = panel === "scan";
    const showNoListing = panel === "no-listing";
    const showResults = panel === "results";

    scanState.classList.toggle("is-hidden", !showScan);
    noListingState.classList.toggle("is-hidden", !showNoListing);
    resultsState.classList.toggle("is-hidden", !showResults);

    scanState.setAttribute("aria-hidden", String(!showScan));
    noListingState.setAttribute("aria-hidden", String(!showNoListing));
    resultsState.setAttribute("aria-hidden", String(!showResults));

    scanButton.disabled = showNoListing;
    retryScanButton.disabled = false;

    const resultsActive = showResults || showNoListing;
    devToggle?.classList.toggle("is-active", resultsActive);
    devToggle?.setAttribute("aria-pressed", String(resultsActive));
  };

  const setResultsVisible = (isVisible) => {
    setActivePanel(isVisible ? "results" : "scan");
  };

  const updateListingsSummary = () => {
    listingsSummaryTitle.textContent = "Pronađen pojedinačni oglas na stranici";
    summaryBadge.textContent = listings.length === 1 ? "1 aktivan" : "0 aktivnih";
  };

  const isNoListingsFoundResult = (result) =>
    !result ||
    result.type === "NO_LISTINGS_FOUND" ||
    (Array.isArray(result.listings) && result.listings.length === 0 && result.is_valid_listing !== true) ||
    result.is_valid_listing === false ||
    !result.listing;

  const isValidDetectionPayload = (result) => {
    if (!result || result.type === "NO_LISTINGS_FOUND") {
      return false;
    }

    const signals = result?.detection?.signals;
    const passesStrongJsonLdRule = signals?.has_strong_json_ld === true;
    const passesDomHeuristicRule =
      signals?.has_price === true &&
      signals?.has_explicit_dom_area === true &&
      signals?.has_property_context === true;
    const passesListingRules =
      signals?.is_collection_like === false &&
      signals?.is_generic_blocked_page === false &&
      (passesStrongJsonLdRule || passesDomHeuristicRule);

    return (
      (result.type === "LISTING_FOUND" || result.schema_version === 1) &&
      result.is_valid_listing === true &&
      typeof result.has_partial_data === "boolean" &&
      Number.isInteger(result.completeness_score) &&
      Array.isArray(result.missing_fields) &&
      result.detection &&
      typeof result.detection.method === "string" &&
      signals &&
      typeof result.listing === "object" &&
      result.listing !== null &&
      passesListingRules
    );
  };

  const formatDetectedPrice = (price) => {
    if (price?.raw) {
      return price.raw;
    }

    if (!Number.isFinite(price?.value)) {
      return "Cena nije pronađena";
    }

    const currencyLabels = {
      EUR: "€",
      USD: "$",
      GBP: "£",
      RSD: "RSD",
    };

    return `${formatNumber(price.value)} ${currencyLabels[price.currency] ?? price.currency ?? ""}`.trim();
  };

  const createDetectedListingId = (listing) => {
    const source = listing?.listing_url || `${listing?.portal_name ?? "detected"}-${Date.now()}`;
    let hash = 0;

    for (let index = 0; index < source.length; index += 1) {
      hash = (hash * 31 + source.charCodeAt(index)) >>> 0;
    }

    return `detected-${hash.toString(36)}`;
  };

  const mapDetectionToListing = (detectionResult) => {
    const detectedListing = detectionResult.listing;

    return {
      id: createDetectedListingId(detectedListing),
      title: detectedListing.title || "Naslov oglasa nije pronađen",
      location: detectedListing.location || "Lokacija nije pronađena",
      price: formatDetectedPrice(detectedListing.price),
      unlocked: false,
      detection: detectionResult,
      hasPartialData: detectionResult.has_partial_data,
      isDetectionValid: detectionResult.is_valid_listing,
    };
  };

  const getActiveTab = async () => {
    if (typeof chrome === "undefined" || !chrome.tabs?.query) {
      return null;
    }

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab ?? null;
  };

  const canInspectTab = (tab) => Boolean(tab?.id && /^https?:\/\//i.test(tab.url ?? ""));

  const inspectActiveTabListing = async () => {
    if (typeof chrome === "undefined" || !chrome.scripting?.executeScript) {
      return null;
    }

    const tab = await getActiveTab();

    if (!canInspectTab(tab)) {
      return null;
    }

    const [injectionResult] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: [LISTING_DETECTOR_FILE],
    });

    return injectionResult?.result ?? null;
  };

  const showNoListingWarningState = () => {
    resetScanResults();
    setScanNotice("");
    setPartialDataWarning(false);
    setActivePanel("no-listing");
  };

  const showInvalidScanState = () => {
    showNoListingWarningState();
  };

  const getListingById = (id) => listings.find((listing) => listing.id === id);

  const ANALYSIS_FIELD_LABELS = {
    summary: "SAŽETAK",
    valuation: "PROCENA VREDNOSTI",
    market_assessment: "Tržišna procena",
    reasoning: "Obrazloženje",
    recommended_checks: "Preporučene provere",
    target_discount_pct: "Ciljani popust",
    target_discount_percentage: "Ciljani popust",
    leverage_points: "Aduti za pregovaranje",
    cost_breakdown: "Struktura troškova",
    red_flags: "Upozorenja i rizici",
    risks: "Upozorenja i rizici",
    costs: "Troškovi",
    legal_checks: "PRAVNE PROVERE",
    legal_check: "Pravna provera",
    technical_checks: "TEHNIČKE PROVERE",
    technical_check: "Tehnička provera",
    legal_technical_checks: "PRAVNE I TEHNIČKE PROVERE",
    negotiation_strategy: "STRATEGIJA PREGOVORA",
    negotiation_strategy_lines: "STRATEGIJA PREGOVORA",
    dynamic_faq: "ČESTA PITANJA",
    dynamic_quick_prompts: "ČESTA PITANJA",
    faq: "ČESTA PITANJA",
    question: "Pitanje",
    answer: "Odgovor",
    financials: "FINANSIJSKI PREGLED",
    deal_score: "AI OCENA PONUDE",
    highlights: "PREDNOSTI",
  };

  const formatAnalysisLabel = (key) => {
    const normalizedKey = String(key ?? "")
      .trim()
      .toLowerCase()
      .replace(/[\s-]+/g, "_");

    return (
      ANALYSIS_FIELD_LABELS[normalizedKey] ||
      normalizedKey
      .replace(/_/g, " ")
      .replace(/^\p{L}/u, (letter) => letter.toUpperCase())
    );
  };

  const renderStructuredValue = (value, key = "") => {
    if (value === null || value === undefined || value === "") {
      return '<p class="muted-label">Nema dostupnih podataka.</p>';
    }

    if (Array.isArray(value)) {
      if (value.length === 0) {
        return '<p class="muted-label">Nema izdvojenih stavki.</p>';
      }

      return `
        <ul class="risk-list">
          ${value
            .map(
              (item) => `
                <li class="risk-item">
                  ${renderStructuredValue(item)}
                </li>
              `,
            )
            .join("")}
        </ul>
      `;
    }

    if (typeof value === "object") {
      return Object.entries(value)
        .map(
          ([nestedKey, nestedValue]) => `
            <div class="analysis-detail">
              <strong>${escapeHtml(formatAnalysisLabel(nestedKey))}</strong>
              ${renderStructuredValue(nestedValue, nestedKey)}
            </div>
          `,
        )
        .join("");
    }

    const displayValue =
      typeof value === "boolean" ? (value ? "Da" : "Ne") : String(value);
    return `<p class="${key === "summary" ? "score-caption" : "muted-label"}">${escapeHtml(displayValue)}</p>`;
  };

  const renderAnalysisModule = ([key, value]) => `
    <section class="analysis-module" aria-label="${escapeHtml(formatAnalysisLabel(key))}">
      <p class="module-kicker">${escapeHtml(formatAnalysisLabel(key))}</p>
      ${renderStructuredValue(value, key)}
    </section>
  `;

  const isAnalysisObject = (value) =>
    Boolean(value) && typeof value === "object" && !Array.isArray(value);

  const firstAvailable = (...values) =>
    values.find((value) => value !== null && value !== undefined && value !== "");

  const collectTextItems = (value) => {
    if (value === null || value === undefined || value === "") {
      return [];
    }

    if (Array.isArray(value)) {
      return value.flatMap(collectTextItems);
    }

    if (isAnalysisObject(value)) {
      return Object.values(value).flatMap(collectTextItems);
    }

    return [String(value)];
  };

  const renderMetricDisplay = (value, key) => {
    if (value === null || value === undefined || value === "") {
      return "—";
    }

    if (!Number.isFinite(Number(value))) {
      return escapeHtml(value);
    }

    const numericValue = Number(value);

    if (key.includes("percentage") || key.includes("pct")) {
      return `${numericValue > 0 ? "+" : ""}${numericValue}%`;
    }

    if (key.includes("price") || key.includes("cost")) {
      return `${formatNumber(numericValue)} €`;
    }

    return escapeHtml(numericValue);
  };

  const renderContactCard = (listing, analysis) => {
    const detectedListing = listing?.detection?.listing ?? {};
    const financials = isAnalysisObject(analysis.financials) ? analysis.financials : {};
    const contact = isAnalysisObject(analysis.contact)
      ? analysis.contact
      : isAnalysisObject(analysis.seller_contact)
        ? analysis.seller_contact
        : {};
    const phone = firstAvailable(
      contact.phone,
      contact.phone_number,
      analysis.phone,
      analysis.phone_number,
      detectedListing.phone,
      detectedListing.phone_number,
    );
    const agency = firstAvailable(
      contact.agency,
      contact.agency_name,
      analysis.agency,
      analysis.agency_name,
      financials.seller_type,
      detectedListing.agency,
      detectedListing.agency_name,
    );

    return `
      <section class="contact-card" aria-label="Kontakt i prodavac">
        <div class="contact-card-heading">
          <span class="contact-icon" aria-hidden="true">☎</span>
          <div>
            <p class="module-kicker">KONTAKT &amp; PRODAVAC</p>
            <strong>${escapeHtml(agency || "Podaci o prodavcu nisu dostupni")}</strong>
          </div>
        </div>
        <div class="contact-details">
          <span>Telefon</span>
          <strong>${escapeHtml(phone || "Nije pronađen")}</strong>
        </div>
      </section>
    `;
  };

  const renderPriceMetrics = (analysis) => {
    const financials = isAnalysisObject(analysis.financials) ? analysis.financials : {};
    const valuation = isAnalysisObject(analysis.valuation) ? analysis.valuation : {};
    const metrics = [
      ["price_per_sqm", firstAvailable(financials.price_per_sqm, valuation.price_per_sqm)],
      [
        "location_average_price_per_sqm",
        firstAvailable(
          financials.location_average_price_per_sqm,
          valuation.location_average_price_per_sqm,
        ),
      ],
      [
        "price_difference_percentage",
        firstAvailable(
          financials.price_difference_percentage,
          valuation.price_difference_percentage,
        ),
      ],
    ].filter(([key, value]) => {
      if (value === undefined || value === null || value === "") {
        return false;
      }

      // Never render invented 0 €/m² metrics from empty/mock payloads.
      if (
        typeof value === "number" &&
        value === 0 &&
        (key === "price_per_sqm" || key === "location_average_price_per_sqm")
      ) {
        return false;
      }

      return true;
    });
    const metricLabels = {
      price_per_sqm: "Cena po m²",
      location_average_price_per_sqm: "Prosek lokacije",
      price_difference_percentage: "Razlika od proseka",
    };

    if (metrics.length === 0) {
      return "";
    }

    return `
      <section class="metric-cards" aria-label="Ključni cenovni pokazatelji">
        ${metrics
          .map(
            ([key, value]) => `
              <article class="metric-card ${key === "price_difference_percentage" ? "metric-card-accent" : ""}">
                <span>${metricLabels[key]}</span>
                <strong>${renderMetricDisplay(value, key)}</strong>
              </article>
            `,
          )
          .join("")}
      </section>
    `;
  };

  const renderDealScore = (analysis) => {
    if (!isAnalysisObject(analysis.deal_score)) {
      return "";
    }

    const score = clamp(Number(analysis.deal_score.score) || 0, 0, 10);

    return `
      <section class="analysis-module deal-score-module">
        <div class="module-title-row">
          <p class="module-kicker">AI OCENA PONUDE</p>
          <strong>${escapeHtml(score.toFixed(1))} / 10</strong>
        </div>
        <div class="progress-track score-track" aria-label="Ocena ${escapeHtml(score)} od 10">
          <div class="progress-fill score-fill" style="width: ${score * 10}%"></div>
        </div>
        <p class="score-caption">${escapeHtml(analysis.deal_score.verdict || "")}</p>
      </section>
    `;
  };

  const renderAlertCards = (analysis) => {
    const insights = isAnalysisObject(analysis.insights) ? analysis.insights : {};
    const risks = collectTextItems(
      firstAvailable(analysis.red_flags, analysis.risks, insights.risks),
    );

    return `
      <section class="analysis-module risk-module">
        <p class="module-kicker">UPOZORENJA I RIZICI</p>
        ${
          risks.length > 0
            ? `<div class="alert-list">${risks
                .map(
                  (risk) => `
                    <article class="alert-card">
                      <span aria-hidden="true">!</span>
                      <p>${escapeHtml(risk)}</p>
                    </article>
                  `,
                )
                .join("")}</div>`
            : '<p class="muted-label empty-state">Nisu izdvojena posebna upozorenja.</p>'
        }
      </section>
    `;
  };

  const renderRecommendedChecks = (analysis) => {
    const checks = [
      ...collectTextItems(analysis.recommended_checks),
      ...collectTextItems(analysis.legal_checks),
      ...collectTextItems(analysis.technical_checks),
      ...collectTextItems(analysis.legal_technical_checks),
    ];

    return `
      <section class="analysis-module checks-module">
        <p class="module-kicker">PREPORUČENE PROVERE</p>
        ${
          checks.length > 0
            ? `<div class="check-list">${[...new Set(checks)]
                .map(
                  (check, index) => `
                    <label class="check-item">
                      <input type="checkbox" data-check-index="${index}">
                      <span class="custom-checkbox" aria-hidden="true"></span>
                      <span>${escapeHtml(check)}</span>
                    </label>
                  `,
                )
                .join("")}</div>`
            : '<p class="muted-label empty-state">Nema dodatnih preporučenih provera.</p>'
        }
      </section>
    `;
  };

  const normalizeFaqItems = (analysis) => {
    const source = firstAvailable(
      analysis.dynamic_faq,
      analysis.faq,
      analysis.dynamic_quick_prompts,
    );

    if (!source) {
      return [];
    }

    const items = Array.isArray(source) ? source : [source];

    return items
      .map((item) => {
        if (typeof item === "string") {
          return { question: item, answer: "Odgovor nije dostupan." };
        }

        if (!isAnalysisObject(item)) {
          return null;
        }

        return {
          question: firstAvailable(item.question, item.label, item.title, item.prompt_query),
          answer: firstAvailable(item.answer, item.response, item.content, item.prompt_query),
        };
      })
      .filter((item) => item?.question);
  };

  const renderFaq = (analysis, listingId) => {
    const items = normalizeFaqItems(analysis);

    if (items.length === 0) {
      return '<section class="analysis-module"><p class="muted-label empty-state">Česta pitanja nisu dostupna za ovaj oglas.</p></section>';
    }

    return `
      <div class="faq-list">
        ${items
          .map(
            (item, index) => `
              <article class="faq-item">
                <button
                  class="faq-question"
                  type="button"
                  aria-expanded="false"
                  aria-controls="faq-${listingId}-${index}"
                >
                  <span>${escapeHtml(item.question)}</span>
                  <span class="faq-chevron" aria-hidden="true">⌄</span>
                </button>
                <div class="faq-answer" id="faq-${listingId}-${index}">
                  <div class="faq-answer-inner">${escapeHtml(item.answer || "Odgovor nije dostupan.")}</div>
                </div>
              </article>
            `,
          )
          .join("")}
      </div>
    `;
  };

  const renderOverviewTab = (listing, analysis) => {
    const excludedKeys = new Set([
      "contact",
      "seller_contact",
      "phone",
      "phone_number",
      "agency",
      "agency_name",
      "financials",
      "deal_score",
      "insights",
      "red_flags",
      "risks",
      "recommended_checks",
      "legal_checks",
      "technical_checks",
      "legal_technical_checks",
      "negotiation_strategy",
      "negotiation_strategy_lines",
      "target_discount_pct",
      "target_discount_percentage",
      "leverage_points",
      "dynamic_faq",
      "faq",
      "dynamic_quick_prompts",
    ]);
    const overviewEntries = Object.entries(analysis).filter(([key]) => !excludedKeys.has(key));

    return `
      ${renderContactCard(listing, analysis)}
      ${renderPriceMetrics(analysis)}
      ${renderDealScore(analysis)}
      ${overviewEntries.map(renderAnalysisModule).join("")}
    `;
  };

  const renderNegotiationTab = (analysis) => {
    const insights = isAnalysisObject(analysis.insights) ? analysis.insights : {};
    const entries = [
      ["target_discount_pct", firstAvailable(analysis.target_discount_pct, analysis.target_discount_percentage)],
      ["leverage_points", firstAvailable(analysis.leverage_points, insights.highlights)],
      [
        "negotiation_strategy",
        firstAvailable(analysis.negotiation_strategy, analysis.negotiation_strategy_lines),
      ],
    ].filter(([, value]) => value !== undefined && value !== null && value !== "");

    return entries.length > 0
      ? entries.map(renderAnalysisModule).join("")
      : '<section class="analysis-module"><p class="muted-label empty-state">Strategija pregovaranja nije dostupna.</p></section>';
  };

  const renderAnalysisTabs = (listing, analysis) => `
    <nav class="analysis-tabs" role="tablist" aria-label="Sekcije analize">
      <button class="analysis-tab is-active" type="button" role="tab" data-tab="overview" aria-selected="true">📊 <span>Pregled</span></button>
      <button class="analysis-tab" type="button" role="tab" data-tab="risks" aria-selected="false">🚨 <span>Rizici</span></button>
      <button class="analysis-tab" type="button" role="tab" data-tab="negotiation" aria-selected="false">💬 <span>Pregovaranje</span></button>
      <button class="analysis-tab" type="button" role="tab" data-tab="faq" aria-selected="false">❓ <span>Česta Pitanja</span></button>
    </nav>
    <div class="analysis-tab-panel is-active" role="tabpanel" data-panel="overview">
      ${renderOverviewTab(listing, analysis)}
    </div>
    <div class="analysis-tab-panel" role="tabpanel" data-panel="risks" hidden>
      ${renderAlertCards(analysis)}
      ${renderRecommendedChecks(analysis)}
    </div>
    <div class="analysis-tab-panel" role="tabpanel" data-panel="negotiation" hidden>
      ${renderNegotiationTab(analysis)}
    </div>
    <div class="analysis-tab-panel" role="tabpanel" data-panel="faq" hidden>
      ${renderFaq(analysis, listing.id)}
    </div>
  `;

  const renderAnalysisSkeleton = (listing) => `
    <div
      class="accordion-panel skeleton-panel"
      id="panel-${listing.id}"
      role="region"
      aria-labelledby="trigger-${listing.id}"
      aria-busy="true"
    >
      <div class="analysis-grid skeleton-grid">
        <section class="analysis-module skeleton-status-card" aria-live="polite">
          <p class="skeleton-status-text">
            <span class="skeleton-pulse-dot" aria-hidden="true"></span>
            AI analizira tržišne podatke...
          </p>
        </section>

        <section class="analysis-module skeleton-card skeleton-financials" aria-label="Učitavanje finansijskog pregleda">
          <div class="skeleton-box skeleton-price-box"></div>
          <div class="skeleton-badge-row">
            <span class="skeleton-box skeleton-badge"></span>
            <span class="skeleton-box skeleton-badge"></span>
          </div>
        </section>

        <section class="analysis-module skeleton-card skeleton-score" aria-label="Učitavanje AI ocene ponude">
          <div class="skeleton-box skeleton-score-bar"></div>
        </section>

        <section class="analysis-module skeleton-card skeleton-insights" aria-label="Učitavanje rizika i prednosti">
          <div class="skeleton-box skeleton-line skeleton-line-100"></div>
          <div class="skeleton-box skeleton-line skeleton-line-80"></div>
          <div class="skeleton-box skeleton-line skeleton-line-60"></div>
        </section>

        <section class="analysis-module skeleton-card skeleton-prompts" aria-label="Učitavanje brzih upita">
          <div class="skeleton-chip-row">
            <span class="skeleton-box skeleton-chip"></span>
            <span class="skeleton-box skeleton-chip"></span>
            <span class="skeleton-box skeleton-chip"></span>
          </div>
        </section>
      </div>
    </div>
  `;

  const renderListingDetails = (listing) => {
    const { analysis } = listing;

    if (!analysis) {
      return "";
    }

    return `
      <div class="accordion-panel analysis-ready" id="panel-${listing.id}" role="region" aria-labelledby="trigger-${listing.id}">
        <div class="analysis-grid">
          ${renderAnalysisTabs(listing, analysis)}
          <section class="analysis-module action-module" aria-label="Akcije">
            <button class="save-dashboard-button" type="button" data-listing-id="${listing.id}">Sačuvaj na Dashboard</button>
            <p class="action-feedback" id="feedback-${listing.id}" aria-live="polite"></p>
          </section>
        </div>
      </div>
    `;
  };

  const renderListing = (listing) => {
    const isOpen = listing.unlocked && listing.id === openListingId;
    const cardStateClass = listing.unlocked ? "is-unlocked" : "is-locked";
    const isAnalyzing = analyzingListingId === listing.id;
    const lockedHelpText = listing.analysisError || "Analiza ovog oglasa još nije pokrenuta.";

    if (isAnalyzing) {
      return `
        <article class="listing-card is-unlocked is-open is-analysis-loading" data-listing-id="${listing.id}">
          <button
            id="trigger-${listing.id}"
            class="listing-trigger skeleton-trigger"
            type="button"
            data-listing-id="${listing.id}"
            aria-expanded="true"
            aria-controls="panel-${listing.id}"
            aria-busy="true"
            disabled
          >
            <span class="listing-main">
              <span class="listing-title">${escapeHtml(listing.title)}</span>
              <span class="listing-meta">${escapeHtml(listing.location)}</span>
            </span>
            <span class="listing-side">
              <strong>${escapeHtml(listing.price)}</strong>
              <span class="badge badge-warning">Analiza u toku</span>
            </span>
          </button>

          ${renderAnalysisSkeleton(listing)}
        </article>
      `;
    }

    if (!listing.unlocked) {
      return `
        <article class="listing-card ${cardStateClass}" data-listing-id="${listing.id}">
          <div class="listing-trigger locked-trigger" aria-describedby="locked-help-${listing.id}">
            <span class="listing-main">
              <span class="listing-title">${escapeHtml(listing.title)}</span>
              <span class="listing-meta">${escapeHtml(listing.location)}</span>
            </span>
            <span class="listing-side">
              <strong>${escapeHtml(listing.price)}</strong>
              <button
                class="unlock-button unlock-inline ${isAnalyzing ? "is-loading" : ""}"
                type="button"
                data-listing-id="${listing.id}"
                ${isAnalyzing ? "disabled" : ""}
                aria-busy="${String(isAnalyzing)}"
              >
                <span aria-hidden="true">${isAnalyzing ? "⏳" : "🔒"}</span>
                <span>${isAnalyzing ? "Analiziram..." : "Otključaj analizu (-1 kredit)"}</span>
              </button>
            </span>
          </div>
          <p id="locked-help-${listing.id}" class="locked-help ${
            listing.analysisError ? "unlock-error" : ""
          }">${escapeHtml(lockedHelpText)}</p>
        </article>
      `;
    }

    return `
      <article class="listing-card ${cardStateClass} ${isOpen ? "is-open" : ""}" data-listing-id="${listing.id}">
        <button
          id="trigger-${listing.id}"
          class="listing-trigger"
          type="button"
          data-listing-id="${listing.id}"
          aria-expanded="${String(isOpen)}"
          aria-controls="panel-${listing.id}"
        >
          <span class="listing-main">
            <span class="listing-title">${escapeHtml(listing.title)}</span>
            <span class="listing-meta">${escapeHtml(listing.location)}</span>
          </span>
          <span class="listing-side">
            <strong>${escapeHtml(listing.price)}</strong>
            <span class="badge badge-success">Analizirano</span>
          </span>
          <span class="accordion-indicator" aria-hidden="true">
            <svg class="accordion-icon accordion-icon-arrow" viewBox="0 0 24 24" focusable="false">
              <path d="m6 9 6 6 6-6"></path>
            </svg>
            <svg class="accordion-icon accordion-icon-close" viewBox="0 0 24 24" focusable="false">
              <path d="M6 6l12 12M18 6 6 18"></path>
            </svg>
          </span>
        </button>

        ${isOpen ? renderListingDetails(listing) : ""}
      </article>
    `;
  };

  const renderListings = () => {
    updateListingsSummary();

    if (listings.length === 0) {
      purgeListingDom();
      return;
    }

    accordion.innerHTML = listings.map(renderListing).join("");
  };

  const collectActiveTabPageContent = async () => {
    if (typeof chrome === "undefined" || !chrome.scripting?.executeScript) {
      return { html: "", rawText: "" };
    }

    const tab = await getActiveTab();

    if (!canInspectTab(tab)) {
      return { html: "", rawText: "" };
    }

    try {
      const [injectionResult] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => ({
          html: document.documentElement?.outerHTML?.slice(0, 120000) || "",
          rawText: document.body?.innerText?.trim()?.slice(0, 40000) || "",
        }),
      });

      return {
        html: injectionResult?.result?.html || "",
        rawText: injectionResult?.result?.rawText || "",
      };
    } catch (error) {
      console.error("Failed to collect page content for analysis.", error);
      return { html: "", rawText: "" };
    }
  };

  const buildAnalysisRequestListing = async (listing) => {
    const detectedListing = listing?.detection?.listing;
    const features =
      listing?.detection?.detection?.signals?.property_context_matches ?? [];
    const sqm = detectedListing?.surface_area?.sqm ?? null;
    const description = detectedListing?.description ?? "";
    const pageContent = await collectActiveTabPageContent();
    const rawText =
      pageContent.rawText ||
      [detectedListing?.title, description, detectedListing?.location]
        .filter(Boolean)
        .join("\n\n");

    return {
      title: detectedListing?.title ?? "",
      price: detectedListing?.price?.value ?? detectedListing?.price?.raw ?? null,
      location: detectedListing?.location ?? "",
      sqm,
      m2: sqm,
      description,
      html: pageContent.html || "",
      rawText,
      features: Array.isArray(features) ? features : [],
      portal_url: detectedListing?.listing_url ?? "",
    };
  };

  const getAnalysisAccessToken = async () => {
    const storedSession = await getStoredSessionSnapshot();
    return parseStoredSession(storedSession)?.accessToken ?? lastAppliedAccessToken;
  };

  const consumeCredit = async () => {
    if (!currentUser || !currentProfile) {
      showToast("Prijavite se na sajtu da biste koristili analizu.");
      return null;
    }

    const previousCredits = credits;
    const nextCredits = previousCredits - CREDIT_COST_PER_UNLOCK;

    if (previousCredits <= 0 || nextCredits < 0) {
      showToast("Nemate dovoljno kredita.");
      return null;
    }

    const { data, error } = await supabaseClient
      .from("profiles")
      .update({ credits_remaining: nextCredits })
      .eq("id", currentUser.id)
      .eq("credits_remaining", previousCredits)
      .select("*")
      .maybeSingle();

    if (error) {
      throw error;
    }

    if (!data) {
      await fetchAndRenderProfile(currentUser);
      showToast("Krediti su promenjeni. Pokušajte ponovo.");
      return null;
    }

    currentProfile = data;
    renderAuthenticatedProfile(currentProfile, currentUser);
    return data;
  };

  const fetchRealAnalysis = async (listingPayload, accessToken) => {
    const headers = {
      "Content-Type": "application/json",
    };

    if (accessToken) {
      headers.Authorization = `Bearer ${accessToken}`;
    }

    console.log("REAL API REQUEST:", ANALYZE_API_URL, listingPayload);

    let response;

    try {
      response = await fetch(ANALYZE_API_URL, {
        method: "POST",
        headers,
        body: JSON.stringify(listingPayload),
      });
    } catch (error) {
      console.error("Analyze network request failed.", error);
      throw new Error(ANALYZE_API_ERROR_MESSAGE);
    }

    let data = null;

    try {
      data = await response.json();
    } catch {
      data = null;
    }

    console.log("REAL API RESPONSE:", data);

    if (!response.ok) {
      throw new Error(ANALYZE_API_ERROR_MESSAGE);
    }

    const analysis = data?.analysis ?? data?.data?.analysis ?? data?.data ?? data;

    if (!analysis || typeof analysis !== "object" || Array.isArray(analysis)) {
      throw new Error(ANALYZE_API_ERROR_MESSAGE);
    }

    return analysis;
  };

  const unlockListing = async (id) => {
    const listing = getListingById(id);

    if (!listing || listing.unlocked || analyzingListingId) {
      return;
    }

    if (
      isNoListingsFoundResult(currentDetectionResult) ||
      !listing.isDetectionValid ||
      !currentDetectionResult?.is_valid_listing
    ) {
      showNoListingWarningState();
      return;
    }

    if (!currentUser || !currentProfile) {
      showToast("Prijavite se na sajtu da biste koristili analizu.");
      return;
    }

    if (credits <= 0) {
      showToast("Nemate dovoljno kredita.");
      return;
    }

    analyzingListingId = id;
    listing.analysisError = "";
    renderListings();

    try {
      const accessToken = await getAnalysisAccessToken();
      const analysisPayload = await buildAnalysisRequestListing(listing);
      const analysis = await fetchRealAnalysis(analysisPayload, accessToken);

      if (
        isNoListingsFoundResult(currentDetectionResult) ||
        !getListingById(id)?.isDetectionValid
      ) {
        showNoListingWarningState();
        return;
      }

      const updatedProfile = await consumeCredit();

      if (!updatedProfile) {
        listing.analysisError = "Krediti nisu skinuti. Pokušajte ponovo.";
        return;
      }

      listing.analysis = analysis;
      listing.unlocked = true;
      openListingId = id;
    } catch (error) {
      console.error("Failed to unlock listing analysis.", error);
      listing.analysis = undefined;
      listing.unlocked = false;
      listing.analysisError = ANALYZE_API_ERROR_MESSAGE;
    } finally {
      analyzingListingId = null;
      renderListings();
    }
  };

  const toggleListing = (id) => {
    const listing = getListingById(id);

    if (!listing?.unlocked) {
      return;
    }

    openListingId = openListingId === id ? null : id;
    renderListings();
  };

  const setActionFeedback = (id, text) => {
    const feedback = document.querySelector(`#feedback-${id}`);

    if (feedback) {
      feedback.textContent = text;
    }
  };

  accordion.addEventListener("click", (event) => {
    const trigger = event.target.closest(".listing-trigger");
    const unlockButton = event.target.closest(".unlock-button");
    const saveButton = event.target.closest(".save-dashboard-button");
    const tabButton = event.target.closest(".analysis-tab");
    const faqQuestion = event.target.closest(".faq-question");

    if (unlockButton) {
      unlockListing(unlockButton.dataset.listingId);
      return;
    }

    if (tabButton) {
      const details = tabButton.closest(".analysis-ready");
      const activeTab = tabButton.dataset.tab;

      details?.querySelectorAll(".analysis-tab").forEach((button) => {
        const isActive = button === tabButton;
        button.classList.toggle("is-active", isActive);
        button.setAttribute("aria-selected", String(isActive));
      });
      details?.querySelectorAll(".analysis-tab-panel").forEach((panel) => {
        const isActive = panel.dataset.panel === activeTab;
        panel.classList.toggle("is-active", isActive);
        panel.toggleAttribute("hidden", !isActive);
      });
      return;
    }

    if (faqQuestion) {
      const faqItem = faqQuestion.closest(".faq-item");
      const wasOpen = faqItem?.classList.contains("is-open") ?? false;
      const faqList = faqQuestion.closest(".faq-list");

      faqList?.querySelectorAll(".faq-item.is-open").forEach((item) => {
        item.classList.remove("is-open");
        item.querySelector(".faq-question")?.setAttribute("aria-expanded", "false");
      });

      if (!wasOpen) {
        faqItem?.classList.add("is-open");
        faqQuestion.setAttribute("aria-expanded", "true");
      }
      return;
    }

    if (trigger) {
      toggleListing(trigger.dataset.listingId);
      return;
    }

    if (saveButton) {
      setActionFeedback(saveButton.dataset.listingId, "Oglas je sačuvan na Dashboard.");
    }
  });

  const runListingDetection = async ({ showLoading = true } = {}) => {
    const requestId = currentScanRequestId + 1;
    currentScanRequestId = requestId;
    clearScanTimer();
    resetScanResults();
    setActivePanel("scan");
    setScanNotice("");

    if (showLoading) {
      setScannerLoading(true);
    }

    try {
      const detectionResult = await inspectActiveTabListing();

      if (requestId !== currentScanRequestId) {
        return;
      }

      if (isNoListingsFoundResult(detectionResult) || !isValidDetectionPayload(detectionResult)) {
        showNoListingWarningState();
        return;
      }

      currentDetectionResult = detectionResult;
      listings = [mapDetectionToListing(detectionResult)];
      purgeListingDom();
      renderListings();
      setPartialDataWarning(detectionResult.has_partial_data);
      setScanNotice("");
      setActivePanel("results");
    } catch (error) {
      console.error("Listing detection failed.", error);
      if (requestId === currentScanRequestId) {
        showNoListingWarningState();
      }
    } finally {
      if (requestId === currentScanRequestId) {
        analyzingListingId = null;
        setScannerLoading(false);
      }
    }
  };

  scanButton.addEventListener("click", () => {
    void runListingDetection();
  });

  retryScanButton.addEventListener("click", () => {
    void runListingDetection();
  });

  devToggle?.addEventListener("click", () => {
    currentScanRequestId += 1;
    clearScanTimer();
    resetScanResults();
    setScanNotice("");
    setScannerLoading(false);
    setActivePanel("scan");
  });

  const handleStorageChange = (changes, areaName) => {
    if (areaName !== "local" || !(EXTENSION_SESSION_STORAGE_KEY in changes)) {
      return;
    }

    const storedSession = changes[EXTENSION_SESSION_STORAGE_KEY].newValue ?? null;

    if (storedSession === lastStoredSessionValue) {
      return;
    }

    window.clearTimeout(authSyncTimer);
    authSyncTimer = window.setTimeout(() => {
      void applyStoredSession(storedSession, { clearOnMissing: true });
    }, 150);
  };

  const handleAuthStateChange = (_event, session) => {
    if (!session?.user?.id || session.user.id === currentUser?.id) {
      if (!session) {
        void applyStoredSession(null, { clearOnMissing: true });
      }
      return;
    }

    void applyStoredSession(
      JSON.stringify({
        currentSession: session,
        expiresAt: session.expires_at ?? null,
      }),
      { clearOnMissing: true },
    );
  };

  const authSubscription = supabaseClient?.auth?.onAuthStateChange
    ? supabaseClient.auth.onAuthStateChange(handleAuthStateChange).data.subscription
    : null;

  chrome.storage?.onChanged?.addListener(handleStorageChange);

  window.addEventListener("unload", () => {
    chrome.storage?.onChanged?.removeListener(handleStorageChange);
    authSubscription?.unsubscribe();
    unsubscribeFromProfileChanges();
    clearScanTimer();
    window.clearTimeout(authSyncTimer);
    window.clearTimeout(toastTimer);
  });

  renderListings();
  setResultsVisible(false);
  setScanNotice("");
  void initializeAuthState();
});
